import discord
from discord.ext import commands
from discord import app_commands
import os
from dotenv import load_dotenv
import json

load_dotenv()
TOKEN = os.getenv("TOKEN")

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

# ================= CONFIG =================
def carregar_config():
    try:
        with open("config.json", "r") as f:
            return json.load(f)
    except:
        return {}

def salvar_config(data):
    with open("config.json", "w") as f:
        json.dump(data, f, indent=4)

config_data = carregar_config()

# ================= EVENT =================
@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Bot online como {bot.user}")

# ================= COMANDOS =================
@bot.tree.command(name="ping", description="Ver latência")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    embed = discord.Embed(title="🏓 Pong!", color=discord.Color.green())
    embed.add_field(name="Latência", value=f"{latency}ms")
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="comandos", description="Lista de comandos")
async def comandos(interaction: discord.Interaction):
    embed = discord.Embed(title="📜 Comandos", color=discord.Color.blue())
    embed.add_field(name="/ping", value="Latência", inline=False)
    embed.add_field(name="/criar_filas", value="Criar fila", inline=False)
    await interaction.response.send_message(embed=embed, ephemeral=True)

# ================= FILA =================
class FilaView(discord.ui.View):
    def __init__(self, modo):
        super().__init__(timeout=None)
        self.modo = modo
        self.players = []

    async def atualizar_embed(self, interaction):
        embed = interaction.message.embeds[0]
        if self.players:
            lista = "\n".join([p.mention for p in self.players])
        else:
            lista = "Aguardando jogadores..."
        embed.description = f"Modo: {self.modo}\n\n👥 Jogadores:\n{lista}"
        await interaction.message.edit(embed=embed, view=self)

    async def iniciar_partida(self, interaction):
        guild = interaction.guild
        p1, p2 = self.players

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            p1: discord.PermissionOverwrite(view_channel=True),
            p2: discord.PermissionOverwrite(view_channel=True),
        }

        canal = await guild.create_text_channel(
            name=f"partida-{p1.name}-vs-{p2.name}",
            overwrites=overwrites
        )

        embed = discord.Embed(
            title="🔥 PARTIDA INICIADA",
            description=f"{p1.mention} vs {p2.mention}",
            color=discord.Color.red()
        )

        await canal.send(embed=embed)

        self.players = []
        embed_original = interaction.message.embeds[0]
        embed_original.description = f"Modo: {self.modo}\n\n👥 Jogadores:\nAguardando jogadores..."
        await interaction.message.edit(embed=embed_original, view=self)

    @discord.ui.button(label="Entrar", style=discord.ButtonStyle.success)
    async def entrar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user in self.players:
            await interaction.response.send_message("Já está na fila!", ephemeral=True)
            return

        if len(self.players) >= 2:
            await interaction.response.send_message("Fila cheia!", ephemeral=True)
            return

        self.players.append(interaction.user)
        await self.atualizar_embed(interaction)
        await interaction.response.send_message("Entrou!", ephemeral=True)

        if len(self.players) == 2:
            await self.iniciar_partida(interaction)

    @discord.ui.button(label="Sair", style=discord.ButtonStyle.danger)
    async def sair(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user not in self.players:
            await interaction.response.send_message("Você não está na fila!", ephemeral=True)
            return

        self.players.remove(interaction.user)
        await self.atualizar_embed(interaction)
        await interaction.response.send_message("Saiu!", ephemeral=True)

# ================= CRIAR FILA =================
@bot.tree.command(name="criar_filas", description="Criar fila")
async def criar_filas(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🎮 PARTIDA",
        description="Modo: padrão\n\n👥 Jogadores:\nAguardando jogadores...",
        color=discord.Color.green()
    )

    view = FilaView("1v1")
    await interaction.channel.send(embed=embed, view=view)
    await interaction.response.send_message("Fila criada!", ephemeral=True)

bot.run(TOKEN)
