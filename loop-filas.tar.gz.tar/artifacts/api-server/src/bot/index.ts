import {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
} from "discord.js";
import { logger } from "../lib/logger";
import { registerSlashCommands } from "./registerCommands";
import { handleInteraction } from "./handlers/interaction";
import { handleMessage } from "./handlers/message";

let client: Client | null = null;

export function getClient(): Client | null {
  return client;
}

export async function startBot(): Promise<void> {
  const token = process.env["TOKEN_BOT"] ?? process.env["DISCORD_TOKEN"];
  const clientId = process.env["DISCORD_CLIENT_ID"];
  if (!token) {
    logger.warn("TOKEN_BOT ou DISCORD_TOKEN ausente — bot não iniciado");
    return;
  }

  client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates,
    ],
    partials: [Partials.Channel, Partials.Message],
  });

  client.on(Events.ClientReady, (c) => {
    logger.info({ tag: c.user.tag, guilds: c.guilds.cache.size }, "Bot conectado");
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      await handleInteraction(interaction);
    } catch (err) {
      logger.error({ err }, "Erro tratando interação");
      try {
        if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: "❌ Ocorreu um erro ao executar este comando.", ephemeral: true });
        }
      } catch {
        // ignore
      }
    }
  });

  client.on(Events.MessageCreate, async (msg) => {
    try {
      await handleMessage(msg);
    } catch (err) {
      logger.error({ err }, "Erro tratando mensagem");
    }
  });

  try {
    await client.login(token);
  } catch (err) {
    logger.error({ err }, "Falha ao fazer login no Discord");
    return;
  }

  if (clientId) {
    registerSlashCommands(token, clientId).catch((err) =>
      logger.error({ err }, "Falha ao registrar slash commands em background"),
    );
  } else {
    logger.warn("DISCORD_CLIENT_ID ausente — comandos slash não serão registrados");
  }
}
