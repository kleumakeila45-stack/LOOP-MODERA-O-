import pg from "pg";

const { Pool } = pg;

const pool = new Pool({ connectionString: process.env["DATABASE_URL"] });

export interface GuildSettings {
  guild_id: string;
  cargo_mediador: string | null;
  cargo_admin: string | null;
  cargo_analista: string | null;
  taxa: string | number | null;
  aviso: string | null;
  qr_color: string | null;
  qr_border_color: string | null;
  match_channel: string | null;
  coin_winner: number | null;
  coin_loser: number | null;
  bot_nickname: string | null;
  bot_banner: string | null;
  bot_thumb: string | null;
  fila_titulo: string | null;
  fila_modo: string | null;
  fila_tipo: string | null;
  fila_banner: string | null;
  fila_thumb: string | null;
  fila_valores: string | null;
  fila_botoes: string | null;
}

export async function ensureGuildSettings(guildId: string): Promise<GuildSettings> {
  await pool.query(
    `INSERT INTO guild_settings (guild_id) VALUES ($1) ON CONFLICT DO NOTHING`,
    [guildId],
  );
  const r = await pool.query<GuildSettings>(
    `SELECT * FROM guild_settings WHERE guild_id = $1`,
    [guildId],
  );
  return r.rows[0]!;
}

export async function updateGuildSettings(
  guildId: string,
  patch: Partial<GuildSettings>,
): Promise<void> {
  await ensureGuildSettings(guildId);
  const keys = Object.keys(patch).filter((k) => k !== "guild_id");
  if (keys.length === 0) return;
  const sets = keys.map((k, i) => `${k} = $${i + 2}`).join(", ");
  const values = keys.map((k) => (patch as Record<string, unknown>)[k]);
  await pool.query(
    `UPDATE guild_settings SET ${sets} WHERE guild_id = $1`,
    [guildId, ...values],
  );
}

export interface QueueButton {
  guild_id: string;
  button_key: string;
  name: string;
  emoji: string | null;
  color: string;
}

export async function getQueueButtons(guildId: string): Promise<QueueButton[]> {
  const r = await pool.query<QueueButton>(
    `SELECT * FROM queue_buttons WHERE guild_id = $1`,
    [guildId],
  );
  return r.rows;
}

export async function upsertQueueButton(
  guildId: string,
  buttonKey: string,
  patch: { name?: string; emoji?: string | null; color?: string },
): Promise<void> {
  const existing = await pool.query(
    `SELECT * FROM queue_buttons WHERE guild_id = $1 AND button_key = $2`,
    [guildId, buttonKey],
  );
  if (existing.rows.length === 0) {
    await pool.query(
      `INSERT INTO queue_buttons (guild_id, button_key, name, emoji, color) VALUES ($1,$2,$3,$4,$5)`,
      [guildId, buttonKey, patch.name ?? buttonKey, patch.emoji ?? null, patch.color ?? "Secondary"],
    );
    return;
  }
  const sets: string[] = [];
  const vals: unknown[] = [];
  let idx = 3;
  if (patch.name !== undefined) {
    sets.push(`name = $${idx++}`);
    vals.push(patch.name);
  }
  if (patch.emoji !== undefined) {
    sets.push(`emoji = $${idx++}`);
    vals.push(patch.emoji);
  }
  if (patch.color !== undefined) {
    sets.push(`color = $${idx++}`);
    vals.push(patch.color);
  }
  if (sets.length === 0) return;
  await pool.query(
    `UPDATE queue_buttons SET ${sets.join(", ")} WHERE guild_id = $1 AND button_key = $2`,
    [guildId, buttonKey, ...vals],
  );
}

export interface BotButtonGlobal {
  button_key: string;
  name: string;
  color: string;
  emoji: string | null;
}

export async function getGlobalButton(buttonKey: string): Promise<BotButtonGlobal | null> {
  const r = await pool.query<BotButtonGlobal>(
    `SELECT * FROM bot_buttons_global WHERE button_key = $1`,
    [buttonKey],
  );
  return r.rows[0] ?? null;
}

export async function getAllGlobalButtons(): Promise<BotButtonGlobal[]> {
  const r = await pool.query<BotButtonGlobal>(`SELECT * FROM bot_buttons_global ORDER BY button_key`);
  return r.rows;
}

export async function upsertGlobalButton(
  buttonKey: string,
  patch: { name?: string; color?: string; emoji?: string | null },
): Promise<void> {
  const existing = await getGlobalButton(buttonKey);
  if (!existing) {
    await pool.query(
      `INSERT INTO bot_buttons_global (button_key, name, color, emoji) VALUES ($1,$2,$3,$4)`,
      [buttonKey, patch.name ?? buttonKey, patch.color ?? "Secondary", patch.emoji ?? null],
    );
    return;
  }
  const sets: string[] = [];
  const vals: unknown[] = [];
  let idx = 2;
  if (patch.name !== undefined) {
    sets.push(`name = $${idx++}`);
    vals.push(patch.name);
  }
  if (patch.color !== undefined) {
    sets.push(`color = $${idx++}`);
    vals.push(patch.color);
  }
  if (patch.emoji !== undefined) {
    sets.push(`emoji = $${idx++}`);
    vals.push(patch.emoji);
  }
  if (sets.length === 0) return;
  await pool.query(
    `UPDATE bot_buttons_global SET ${sets.join(", ")} WHERE button_key = $1`,
    [buttonKey, ...vals],
  );
}

export interface CustomEmoji {
  guild_id: string;
  emoji_id: string;
  name: string | null;
}

export async function listCustomEmojis(guildId: string): Promise<CustomEmoji[]> {
  const r = await pool.query<CustomEmoji>(
    `SELECT * FROM custom_emojis WHERE guild_id = $1 ORDER BY added_at DESC`,
    [guildId],
  );
  return r.rows;
}

export async function addCustomEmoji(guildId: string, emojiId: string, name: string | null): Promise<void> {
  await pool.query(
    `INSERT INTO custom_emojis (guild_id, emoji_id, name) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
    [guildId, emojiId, name],
  );
}

export async function removeCustomEmoji(guildId: string, emojiId: string): Promise<void> {
  await pool.query(`DELETE FROM custom_emojis WHERE guild_id = $1 AND emoji_id = $2`, [guildId, emojiId]);
}

export interface MediatorPix {
  chave: string;
  titular: string;
  cidade: string;
}

export async function getMediatorPix(guildId: string, userId: string): Promise<MediatorPix | null> {
  const r = await pool.query<MediatorPix>(
    `SELECT chave, titular, cidade FROM mediator_pix WHERE guild_id = $1 AND user_id = $2`,
    [guildId, userId],
  );
  return r.rows[0] ?? null;
}

export async function setMediatorPix(
  guildId: string,
  userId: string,
  pix: MediatorPix,
): Promise<void> {
  await pool.query(
    `INSERT INTO mediator_pix (guild_id, user_id, chave, titular, cidade)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (guild_id, user_id) DO UPDATE SET chave = EXCLUDED.chave, titular = EXCLUDED.titular, cidade = EXCLUDED.cidade`,
    [guildId, userId, pix.chave, pix.titular, pix.cidade],
  );
}

export async function addMediatorToQueue(guildId: string, userId: string, panelMessageId: string | null): Promise<void> {
  await pool.query(
    `INSERT INTO mediators_queue (guild_id, user_id, panel_message_id)
     VALUES ($1,$2,$3)
     ON CONFLICT (guild_id, user_id) DO UPDATE SET panel_message_id = EXCLUDED.panel_message_id`,
    [guildId, userId, panelMessageId],
  );
}

export async function removeMediatorFromQueue(guildId: string, userId: string): Promise<void> {
  await pool.query(`DELETE FROM mediators_queue WHERE guild_id = $1 AND user_id = $2`, [guildId, userId]);
}

export async function listMediatorsInQueue(guildId: string): Promise<string[]> {
  const r = await pool.query<{ user_id: string }>(
    `SELECT user_id FROM mediators_queue WHERE guild_id = $1 ORDER BY joined_at ASC`,
    [guildId],
  );
  return r.rows.map((row) => row.user_id);
}

export async function popNextMediator(guildId: string): Promise<string | null> {
  const r = await pool.query<{ user_id: string }>(
    `SELECT user_id FROM mediators_queue WHERE guild_id = $1 ORDER BY joined_at ASC LIMIT 1`,
    [guildId],
  );
  const userId = r.rows[0]?.user_id;
  if (!userId) return null;
  await removeMediatorFromQueue(guildId, userId);
  return userId;
}

export async function addAnalystToQueue(guildId: string, userId: string, panelMessageId: string | null): Promise<void> {
  await pool.query(
    `INSERT INTO analysts_queue (guild_id, user_id, panel_message_id)
     VALUES ($1,$2,$3)
     ON CONFLICT (guild_id, user_id) DO UPDATE SET panel_message_id = EXCLUDED.panel_message_id`,
    [guildId, userId, panelMessageId],
  );
}

export async function removeAnalystFromQueue(guildId: string, userId: string): Promise<void> {
  await pool.query(`DELETE FROM analysts_queue WHERE guild_id = $1 AND user_id = $2`, [guildId, userId]);
}

export async function listAnalystsInQueue(guildId: string): Promise<string[]> {
  const r = await pool.query<{ user_id: string }>(
    `SELECT user_id FROM analysts_queue WHERE guild_id = $1 ORDER BY joined_at ASC`,
    [guildId],
  );
  return r.rows.map((row) => row.user_id);
}

export async function popNextAnalyst(guildId: string): Promise<string | null> {
  const r = await pool.query<{ user_id: string }>(
    `SELECT user_id FROM analysts_queue WHERE guild_id = $1 ORDER BY joined_at ASC LIMIT 1`,
    [guildId],
  );
  const userId = r.rows[0]?.user_id;
  if (!userId) return null;
  await removeAnalystFromQueue(guildId, userId);
  return userId;
}

export interface BotEmbedOverride {
  embed_key: string;
  title: string | null;
  description: string | null;
  color: string | null;
  footer: string | null;
  image_url: string | null;
  thumb_url: string | null;
}

export async function getEmbedOverride(key: string): Promise<BotEmbedOverride | null> {
  const r = await pool.query<BotEmbedOverride>(
    `SELECT * FROM bot_embeds_global WHERE embed_key = $1`,
    [key],
  );
  return r.rows[0] ?? null;
}

export async function getAllEmbedOverrides(): Promise<BotEmbedOverride[]> {
  const r = await pool.query<BotEmbedOverride>(`SELECT * FROM bot_embeds_global ORDER BY embed_key`);
  return r.rows;
}

export async function upsertEmbedOverride(
  key: string,
  patch: Partial<Omit<BotEmbedOverride, "embed_key">>,
): Promise<void> {
  const existing = await getEmbedOverride(key);
  if (!existing) {
    await pool.query(
      `INSERT INTO bot_embeds_global (embed_key, title, description, color, footer, image_url, thumb_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [key, patch.title ?? null, patch.description ?? null, patch.color ?? null, patch.footer ?? null, patch.image_url ?? null, patch.thumb_url ?? null],
    );
    return;
  }
  const sets: string[] = [];
  const vals: unknown[] = [];
  let idx = 2;
  for (const k of ["title", "description", "color", "footer", "image_url", "thumb_url"] as const) {
    if (patch[k] !== undefined) {
      sets.push(`${k} = $${idx++}`);
      vals.push(patch[k]);
    }
  }
  if (sets.length === 0) return;
  sets.push(`updated_at = NOW()`);
  await pool.query(
    `UPDATE bot_embeds_global SET ${sets.join(", ")} WHERE embed_key = $1`,
    [key, ...vals],
  );
}

export interface BotAppearanceGlobal {
  bio: string | null;
  status_text: string | null;
  status_type: string | null;
  status_presence: string | null;
}

export async function getBotAppearance(): Promise<BotAppearanceGlobal> {
  const r = await pool.query<BotAppearanceGlobal>(
    `SELECT bio, status_text, status_type, status_presence FROM bot_appearance_global WHERE id = 1`,
  );
  return r.rows[0] ?? { bio: null, status_text: null, status_type: null, status_presence: null };
}

export async function setBotAppearance(patch: Partial<BotAppearanceGlobal>): Promise<void> {
  const sets: string[] = [];
  const vals: unknown[] = [];
  let idx = 1;
  for (const k of ["bio", "status_text", "status_type", "status_presence"] as const) {
    if (patch[k] !== undefined) {
      sets.push(`${k} = $${idx++}`);
      vals.push(patch[k]);
    }
  }
  if (sets.length === 0) return;
  await pool.query(
    `INSERT INTO bot_appearance_global (id, bio, status_text, status_type, status_presence)
     VALUES (1, $1, $2, $3, $4)
     ON CONFLICT (id) DO UPDATE SET ${sets.join(", ")}`,
    [
      patch.bio ?? null,
      patch.status_text ?? null,
      patch.status_type ?? null,
      patch.status_presence ?? null,
      ...vals,
    ],
  );
}

export interface ShopItem {
  id: number;
  guild_id: string;
  name: string;
  description: string | null;
  price: string | number;
  item_type: string;
  item_value: string | null;
}

export async function listShopItems(guildId: string): Promise<ShopItem[]> {
  const r = await pool.query<ShopItem>(`SELECT * FROM shop_items WHERE guild_id = $1 ORDER BY id ASC`, [guildId]);
  return r.rows;
}

export async function getShopItem(itemId: number): Promise<ShopItem | null> {
  const r = await pool.query<ShopItem>(`SELECT * FROM shop_items WHERE id = $1`, [itemId]);
  return r.rows[0] ?? null;
}

export async function addShopItem(
  guildId: string,
  patch: { name: string; price: number; item_type: string; item_value?: string | null; description?: string | null },
): Promise<number> {
  const r = await pool.query<{ id: number }>(
    `INSERT INTO shop_items (guild_id, name, description, price, item_type, item_value)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
    [guildId, patch.name, patch.description ?? null, patch.price, patch.item_type, patch.item_value ?? null],
  );
  return r.rows[0]!.id;
}

export async function updateShopItem(
  itemId: number,
  patch: { name?: string; price?: number; item_type?: string; item_value?: string | null; description?: string | null },
): Promise<void> {
  const sets: string[] = [];
  const vals: unknown[] = [];
  let idx = 2;
  for (const k of ["name", "price", "item_type", "item_value", "description"] as const) {
    if (patch[k] !== undefined) {
      sets.push(`${k} = $${idx++}`);
      vals.push(patch[k]);
    }
  }
  if (sets.length === 0) return;
  await pool.query(`UPDATE shop_items SET ${sets.join(", ")} WHERE id = $1`, [itemId, ...vals]);
}

export async function removeShopItem(itemId: number): Promise<void> {
  await pool.query(`DELETE FROM shop_items WHERE id = $1`, [itemId]);
}

export interface ShopAppearance {
  guild_id: string;
  banner: string | null;
  thumb: string | null;
}

export async function getShopAppearance(guildId: string): Promise<ShopAppearance> {
  const r = await pool.query<ShopAppearance>(`SELECT * FROM shop_appearance WHERE guild_id = $1`, [guildId]);
  return r.rows[0] ?? { guild_id: guildId, banner: null, thumb: null };
}

export async function setShopAppearance(
  guildId: string,
  patch: { banner?: string | null; thumb?: string | null },
): Promise<void> {
  await pool.query(
    `INSERT INTO shop_appearance (guild_id, banner, thumb)
     VALUES ($1, $2, $3)
     ON CONFLICT (guild_id) DO UPDATE SET
       banner = COALESCE($2, shop_appearance.banner),
       thumb = COALESCE($3, shop_appearance.thumb),
       updated_at = NOW()`,
    [guildId, patch.banner ?? null, patch.thumb ?? null],
  );
  if (patch.banner === null || patch.thumb === null) {
    const sets: string[] = [];
    if (patch.banner === null) sets.push(`banner = NULL`);
    if (patch.thumb === null) sets.push(`thumb = NULL`);
    if (sets.length > 0) {
      await pool.query(`UPDATE shop_appearance SET ${sets.join(", ")} WHERE guild_id = $1`, [guildId]);
    }
  }
}

export async function addCoins(guildId: string, userId: string, amount: number): Promise<void> {
  await pool.query(
    `INSERT INTO user_coins (guild_id, user_id, amount) VALUES ($1,$2,$3)
     ON CONFLICT (guild_id, user_id) DO UPDATE SET amount = user_coins.amount + EXCLUDED.amount`,
    [guildId, userId, amount],
  );
}

export async function recordMatch(
  guildId: string,
  player1: string,
  player2: string,
  winner: string,
  mediator: string | null,
  amount: number,
): Promise<void> {
  await pool.query(
    `INSERT INTO match_history (guild_id, player1, player2, winner, mediator, amount) VALUES ($1,$2,$3,$4,$5,$6)`,
    [guildId, player1, player2, winner, mediator, amount],
  );
}
