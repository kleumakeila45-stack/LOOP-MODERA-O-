import type { ComponentEmojiResolvable } from "discord.js";

export function parseEmojiInput(raw: string | null | undefined): ComponentEmojiResolvable | undefined {
  if (!raw) return undefined;
  const trimmed = raw.trim();
  if (!trimmed) return undefined;

  const fullMatch = trimmed.match(/<(a?):([A-Za-z0-9_]+):(\d+)>/);
  if (fullMatch) {
    return {
      animated: fullMatch[1] === "a",
      name: fullMatch[2]!,
      id: fullMatch[3]!,
    };
  }

  if (/^\d{15,25}$/.test(trimmed)) {
    return { id: trimmed };
  }

  if (/^<a?:([A-Za-z0-9_]+):(\d+)$/.test(trimmed)) {
    const m = trimmed.match(/^<(a?):([A-Za-z0-9_]+):(\d+)/);
    if (m) return { animated: m[1] === "a", name: m[2]!, id: m[3]! };
  }

  return trimmed;
}

export function emojiToText(raw: string | null | undefined): string {
  if (!raw) return "";
  const trimmed = raw.trim();
  if (/^\d{15,25}$/.test(trimmed)) {
    return `<:e:${trimmed}>`;
  }
  return trimmed;
}
