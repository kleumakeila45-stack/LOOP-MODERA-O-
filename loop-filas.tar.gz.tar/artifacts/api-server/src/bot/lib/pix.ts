import QRCode from "qrcode";

function tlv(id: string, value: string): string {
  const len = value.length.toString().padStart(2, "0");
  return `${id}${len}${value}`;
}

function crc16(payload: string): string {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) crc = ((crc << 1) ^ 0x1021) & 0xffff;
      else crc = (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

function strip(text: string, max: number): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Za-z0-9 ]/g, "")
    .toUpperCase()
    .slice(0, max);
}

export interface PixParams {
  chave: string;
  titular: string;
  cidade: string;
  amount?: string;
}

export function buildPixPayload({ chave, titular, cidade, amount }: PixParams): string {
  const merchantAccount = tlv("00", "br.gov.bcb.pix") + tlv("01", chave.trim());
  let payload =
    tlv("00", "01") +
    tlv("26", merchantAccount) +
    tlv("52", "0000") +
    tlv("53", "986");
  if (amount) {
    const a = amount.replace(",", ".");
    const num = Number(a);
    if (!Number.isNaN(num) && num > 0) {
      payload += tlv("54", num.toFixed(2));
    }
  }
  payload +=
    tlv("58", "BR") +
    tlv("59", strip(titular, 25) || "RECEBEDOR") +
    tlv("60", strip(cidade, 15) || "BRASIL") +
    tlv("62", tlv("05", "***"));
  payload += "6304";
  payload += crc16(payload);
  return payload;
}

export async function generatePixQrPng(
  params: PixParams,
  color = "#000000",
  background = "#FFFFFF",
): Promise<Buffer> {
  const payload = buildPixPayload(params);
  return QRCode.toBuffer(payload, {
    type: "png",
    errorCorrectionLevel: "M",
    margin: 2,
    width: 512,
    color: {
      dark: color || "#000000",
      light: background || "#FFFFFF",
    },
  });
}
