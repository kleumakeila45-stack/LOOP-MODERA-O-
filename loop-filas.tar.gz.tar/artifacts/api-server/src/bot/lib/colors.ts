import { ButtonStyle } from "discord.js";

export type ButtonColorName = "primary" | "secondary" | "success" | "danger" | "link";

const COLOR_MAP: Record<string, ButtonStyle> = {
  azul: ButtonStyle.Primary,
  primario: ButtonStyle.Primary,
  primary: ButtonStyle.Primary,
  cinza: ButtonStyle.Secondary,
  cinzento: ButtonStyle.Secondary,
  secondary: ButtonStyle.Secondary,
  verde: ButtonStyle.Success,
  green: ButtonStyle.Success,
  success: ButtonStyle.Success,
  vermelho: ButtonStyle.Danger,
  red: ButtonStyle.Danger,
  danger: ButtonStyle.Danger,
  link: ButtonStyle.Link,
};

export function parseButtonColor(name: string | null | undefined): ButtonStyle {
  if (!name) return ButtonStyle.Secondary;
  const normalized = name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
  return COLOR_MAP[normalized] ?? ButtonStyle.Secondary;
}

export function colorNameFromStyle(style: ButtonStyle): string {
  switch (style) {
    case ButtonStyle.Primary:
      return "azul";
    case ButtonStyle.Success:
      return "verde";
    case ButtonStyle.Danger:
      return "vermelho";
    case ButtonStyle.Link:
      return "link";
    default:
      return "cinza";
  }
}

export function parseHexColor(input: string | null | undefined, fallback: string): string {
  if (!input) return fallback;
  let v = input.trim().replace(/^#/, "");
  if (/^[0-9a-fA-F]{3}$/.test(v)) {
    v = v
      .split("")
      .map((c) => c + c)
      .join("");
  }
  if (/^[0-9a-fA-F]{6}$/.test(v)) return `#${v.toUpperCase()}`;
  return fallback;
}
