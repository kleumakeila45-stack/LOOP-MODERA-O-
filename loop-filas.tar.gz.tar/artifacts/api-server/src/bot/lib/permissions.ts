import { GuildMember } from "discord.js";
import { ensureGuildSettings } from "./store";

export const HARDCODED_ADMIN_ROLE_ID = "1464521686484517068";

export async function isBotAdmin(member: GuildMember | null | undefined): Promise<boolean> {
  if (!member) return false;
  if (member.permissions.has("Administrator")) return true;
  if (member.roles.cache.has(HARDCODED_ADMIN_ROLE_ID)) return true;
  const settings = await ensureGuildSettings(member.guild.id);
  if (settings.cargo_admin && member.roles.cache.has(settings.cargo_admin)) return true;
  return false;
}

export async function isMediator(member: GuildMember | null | undefined): Promise<boolean> {
  if (!member) return false;
  const settings = await ensureGuildSettings(member.guild.id);
  if (settings.cargo_mediador && member.roles.cache.has(settings.cargo_mediador)) return true;
  return false;
}
