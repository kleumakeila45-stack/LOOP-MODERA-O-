export interface ActiveQueuePlayer {
  userId: string;
  buttonKey: string;
  buttonName: string;
}

export interface ActiveQueue {
  guildId: string;
  channelId: string;
  messageId: string;
  modo: string;
  tipo: string;
  price: string;
  players: Map<string, ActiveQueuePlayer>;
}

export interface ActiveMatch {
  guildId: string;
  channelId: string;
  panelMessageId: string | null;
  player1: string;
  player2: string;
  buttonKey: string;
  price: string;
  modo: string;
  tipo: string;
  confirmed: Set<string>;
  mediatorId: string | null;
  mediatorPanelMessageId: string | null;
  analystId: string | null;
}

export const activeQueues = new Map<string, ActiveQueue>();
export const activeMatches = new Map<string, ActiveMatch>();

export function findQueueByMessage(messageId: string): ActiveQueue | undefined {
  return activeQueues.get(messageId);
}

export function findMatchByChannel(channelId: string): ActiveMatch | undefined {
  return activeMatches.get(channelId);
}
