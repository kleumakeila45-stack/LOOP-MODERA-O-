import {
  REST,
  Routes,
  SlashCommandBuilder,
  type RESTPostAPIApplicationCommandsJSONBody,
} from "discord.js";
import { logger } from "../lib/logger";

function buildSlashCommands(): RESTPostAPIApplicationCommandsJSONBody[] {
  const cmds: RESTPostAPIApplicationCommandsJSONBody[] = [];

  cmds.push(new SlashCommandBuilder().setName("comandos").setDescription("Mostra todos os comandos do bot").toJSON());

  cmds.push(
    new SlashCommandBuilder()
      .setName("bot")
      .setDescription("Configurações de aparência do bot")
      .addSubcommand((sub) => sub.setName("aparencia").setDescription("Painel para editar nome, banner, thumbnail, bio e status do bot"))
      .toJSON(),
  );

  cmds.push(
    new SlashCommandBuilder()
      .setName("criar")
      .setDescription("Comandos de criação")
      .addSubcommand((sub) => sub.setName("org").setDescription("Recria todo o servidor com a estrutura padrão de filas"))
      .toJSON(),
  );

  cmds.push(new SlashCommandBuilder().setName("botões").setDescription("Painel para editar botões das filas").toJSON());

  cmds.push(new SlashCommandBuilder().setName("configurações").setDescription("Painel de configurações do bot").toJSON());

  cmds.push(new SlashCommandBuilder().setName("filas").setDescription("Painel para configurar e enviar as filas").toJSON());

  cmds.push(
    new SlashCommandBuilder()
      .setName("fila")
      .setDescription("Comandos de fila")
      .addSubcommand((sub) => sub.setName("mediador").setDescription("Painel da fila de mediadores"))
      .addSubcommand((sub) => sub.setName("analista").setDescription("Painel da fila de analistas"))
      .toJSON(),
  );

  cmds.push(new SlashCommandBuilder().setName("sala").setDescription("Envia o ID e a senha da sala").toJSON());

  cmds.push(
    new SlashCommandBuilder()
      .setName("loja")
      .setDescription("Loja de prêmios")
      .addSubcommand((sub) => sub.setName("coins").setDescription("Painel de prêmios trocados por coins"))
      .toJSON(),
  );

  return cmds;
}

export async function registerSlashCommands(token: string, clientId: string): Promise<void> {
  const rest = new REST({ version: "10" }).setToken(token);
  const body = buildSlashCommands();
  try {
    await rest.put(Routes.applicationCommands(clientId), { body });
    logger.info({ count: body.length }, "Slash commands registrados globalmente");
  } catch (err) {
    logger.error({ err }, "Falha ao registrar comandos slash");
  }
}
