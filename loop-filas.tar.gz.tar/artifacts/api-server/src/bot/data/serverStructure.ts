import { ChannelType } from "discord.js";

export interface ChannelDef {
  name: string;
  type: "text" | "voice";
  private?: boolean;
}

export interface CategoryDef {
  name: string;
  channels: ChannelDef[];
  privateRoles?: string[];
}

export const SERVER_CATEGORIES: CategoryDef[] = [
  {
    name: "EQUIPE",
    privateRoles: ["DONO", "MEDIADOR", "ANALISTA", "SUPORTE"],
    channels: [
      { name: "💎・config-pix", type: "text", private: true },
      { name: "💎・fila-adm", type: "text", private: true },
      { name: "💎・chat-equipe", type: "text", private: true },
      { name: "🔎・fila-analista", type: "text", private: true },
    ],
  },
  {
    name: "INFORMAÇÕES",
    channels: [
      { name: "👀・tiktok", type: "text" },
      { name: "👀・instagram", type: "text" },
      { name: "🚨・avisos", type: "text" },
    ],
  },
  {
    name: "REGRAS",
    channels: [
      { name: "📕・regras-x1", type: "text" },
      { name: "📔・regras-servidor", type: "text" },
    ],
  },
  {
    name: "ATENDIMENTO",
    channels: [
      { name: "📮・tickets", type: "text" },
      { name: "☎️・suporte", type: "text" },
    ],
  },
  {
    name: "FILAS MOBILE",
    channels: [
      { name: "📱・1v1-mobile", type: "text" },
      { name: "📱・2v2-mobile", type: "text" },
      { name: "📱・3v3-mobile", type: "text" },
      { name: "📱・4v4-mobile", type: "text" },
    ],
  },
  {
    name: "FILAS EMULADOR",
    channels: [
      { name: "🖥・1v1-emulador", type: "text" },
      { name: "🖥・2v2-emulador", type: "text" },
      { name: "🖥・3v3-emulador", type: "text" },
      { name: "🖥・4v4-emulador", type: "text" },
    ],
  },
  {
    name: "FILAS MISTAS",
    channels: [
      { name: "📱🖥・2v2-misto", type: "text" },
      { name: "📱🖥・3v3-misto", type: "text" },
      { name: "📱🖥・4v4-misto", type: "text" },
    ],
  },
  {
    name: "EVENTOS",
    channels: [
      { name: "🎉・sorteios", type: "text" },
      { name: "💸・1win-2no-pix", type: "text" },
    ],
  },
  {
    name: "COINS",
    channels: [
      { name: "🛒・loja", type: "text" },
      { name: "🎡・roleta", type: "text" },
    ],
  },
  {
    name: "RANKING",
    privateRoles: ["DONO", "MEDIADOR", "ANALISTA", "SUPORTE"],
    channels: [
      { name: "🏅・ranking", type: "text" },
      { name: "💎・ranking-adm", type: "text", private: true },
      { name: "🚫・blacklist", type: "text" },
    ],
  },
  {
    name: "ANÁLISE",
    channels: [
      { name: "📘・regras-telagem", type: "text" },
      ...Array.from({ length: 15 }, (_, i) => ({
        name: `🔎・análise ${i + 1}`,
        type: "voice" as const,
      })),
    ],
  },
];

export interface RoleDef {
  name: string;
  hoist?: boolean;
  permissions: bigint;
  color?: number;
  isAdminRole?: boolean;
}

export const SERVER_ROLES: RoleDef[] = [
  {
    name: "👑 ・ DONO",
    hoist: true,
    permissions: 8n,
    color: 0xffd700,
    isAdminRole: true,
  },
  {
    name: "💎 ・ MEDIADOR",
    hoist: true,
    permissions: 0n,
    color: 0x5dade2,
  },
  {
    name: "🔎 ・ ANALISTA",
    hoist: true,
    permissions: 0n,
    color: 0x58d68d,
  },
  {
    name: "☎️ ・ SUPORTE",
    hoist: true,
    permissions: 0n,
    color: 0xaf7ac5,
  },
];

export function getDiscordChannelType(t: "text" | "voice"): ChannelType {
  return t === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText;
}
