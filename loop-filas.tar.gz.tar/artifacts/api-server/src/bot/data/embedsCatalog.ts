export interface EmbedDef {
  key: string;
  label: string;
  category: string;
  defaultTitle: string;
  defaultDescription: string;
  defaultColor: string;
  defaultFooter?: string;
}

export const EMBED_DEFS: EmbedDef[] = [
  {
    key: "comandos",
    label: "Lista de Comandos",
    category: "Painéis",
    defaultTitle: "📜 ・ Lista de Comandos",
    defaultDescription:
      "Aqui está tudo que o bot pode fazer. Use o comando indicado para abrir cada painel.",
    defaultColor: "#5865F2",
    defaultFooter: "FreeFire Filas • Sistema de Apostas",
  },
  {
    key: "bot_aparencia",
    label: "Aparência do Bot",
    category: "Painéis",
    defaultTitle: "🎨 ・ Aparência do Bot",
    defaultDescription:
      "Edite o nome, banner, thumbnail, bio e status do bot.",
    defaultColor: "#E67E22",
  },
  {
    key: "configuracoes",
    label: "Configurações do Bot",
    category: "Painéis",
    defaultTitle: "⚙️ ・ Configurações do Bot",
    defaultDescription:
      "Use os botões abaixo para configurar o bot. Cada configuração é salva automaticamente.",
    defaultColor: "#95A5A6",
  },
  {
    key: "filas_painel",
    label: "Painel de Filas",
    category: "Painéis",
    defaultTitle: "📊 ・ Painel de Filas",
    defaultDescription: "Use os menus abaixo para configurar e enviar as filas.",
    defaultColor: "#1ABC9C",
  },
  {
    key: "fila_mediador",
    label: "Fila de Mediadores",
    category: "Mediadores/Analistas",
    defaultTitle: "🤝 ・ Fila de Mediadores",
    defaultDescription:
      "Mediadores podem configurar seu PIX e entrar na fila para serem chamados em partidas.",
    defaultColor: "#9B59B6",
  },
  {
    key: "fila_analista",
    label: "Fila de Analistas",
    category: "Mediadores/Analistas",
    defaultTitle: "🔍 ・ Fila de Analistas",
    defaultDescription:
      "Analistas podem entrar na fila para serem chamados em partidas pelas equipes.",
    defaultColor: "#3498DB",
  },
  {
    key: "mediador_chamado",
    label: "Mediador Chamado",
    category: "Partida",
    defaultTitle: "🤝 ・ Mediador chamado",
    defaultDescription: "Você foi chamado para mediar esta partida.",
    defaultColor: "#9B59B6",
  },
  {
    key: "analista_chamado",
    label: "Analista Chamado",
    category: "Partida",
    defaultTitle: "🔍 ・ Analista chamado",
    defaultDescription: "Você foi chamado para analisar esta partida.",
    defaultColor: "#3498DB",
  },
  {
    key: "match_found",
    label: "Partida Encontrada",
    category: "Partida",
    defaultTitle: "⚔️ ・ Partida Encontrada!",
    defaultDescription: "Cada jogador deve clicar em **Confirmar** para iniciar.",
    defaultColor: "#E74C3C",
  },
  {
    key: "qr_code",
    label: "QR Code PIX",
    category: "Partida",
    defaultTitle: "💸 ・ QR Code PIX",
    defaultDescription: "Pague lendo o QR Code abaixo.",
    defaultColor: "#27AE60",
  },
  {
    key: "chave_pix",
    label: "Chave PIX",
    category: "Partida",
    defaultTitle: "🔑 ・ Chave PIX do Mediador",
    defaultDescription: "Use a chave abaixo para pagar.",
    defaultColor: "#16A085",
  },
  {
    key: "vencedor",
    label: "Vencedor Definido",
    category: "Partida",
    defaultTitle: "🏆 ・ Vencedor definido!",
    defaultDescription: "O canal será fechado em 10s.",
    defaultColor: "#F1C40F",
  },
  {
    key: "sala",
    label: "Sala Personalizada",
    category: "Partida",
    defaultTitle: "🏠 ・ Sala Personalizada",
    defaultDescription:
      "📌 As informações da sala foram divulgadas! Entrem com calma e respeitem as regras.",
    defaultColor: "#2ECC71",
  },
  {
    key: "ping",
    label: "Latência",
    category: "Painéis",
    defaultTitle: "🏓 ・ Latência do Bot",
    defaultDescription:
      "Tudo certo por aqui! Aqui estão os números atuais da conexão entre o bot e o Discord.",
    defaultColor: "#5865F2",
    defaultFooter: "FreeFire Filas • Sistema de Apostas",
  },
  {
    key: "loja",
    label: "Loja de Filas",
    category: "Painéis",
    defaultTitle: "🛒 ・ Loja de Filas",
    defaultDescription:
      "Itens disponíveis para troca por coins.",
    defaultColor: "#F1C40F",
  },
  {
    key: "loja_coins",
    label: "Painel da Loja de Coins",
    category: "Painéis",
    defaultTitle: "🪙 ・ Loja de Coins",
    defaultDescription:
      "Administre os prêmios que podem ser trocados por coins.",
    defaultColor: "#F1C40F",
  },
  {
    key: "loja_premio_recebido",
    label: "Prêmio Recebido",
    category: "Painéis",
    defaultTitle: "🎁 ・ Prêmio recebido!",
    defaultDescription: "Você recebeu um prêmio da loja.",
    defaultColor: "#2ECC71",
  },
  {
    key: "editor_botoes",
    label: "Editor Global de Botões",
    category: "Editores",
    defaultTitle: "⚙️ ・ Editor Global de Botões",
    defaultDescription:
      "Escolha um botão no menu abaixo para editar **nome, cor e emoji**.",
    defaultColor: "#9B59B6",
    defaultFooter: "Apenas administradores do bot",
  },
  {
    key: "editor_embeds",
    label: "Editor Global de Embeds",
    category: "Editores",
    defaultTitle: "📝 ・ Editor Global de Embeds",
    defaultDescription:
      "Escolha um embed no menu abaixo para editar **título, descrição, cor e rodapé**.",
    defaultColor: "#9B59B6",
    defaultFooter: "Apenas administradores do bot",
  },
  {
    key: "queue_main",
    label: "Embed de Fila (jogadores)",
    category: "Filas",
    defaultTitle: "FILA",
    defaultDescription: "Entre na fila clicando no botão correspondente.",
    defaultColor: "#1ABC9C",
  },
];

export function findEmbedDef(key: string): EmbedDef | undefined {
  return EMBED_DEFS.find((e) => e.key === key);
}

export function embedCategories(): string[] {
  return [...new Set(EMBED_DEFS.map((e) => e.category))];
}
