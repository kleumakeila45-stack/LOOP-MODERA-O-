export interface QueueButtonDef {
  key: string;
  defaultName: string;
  defaultColor: "primary" | "success" | "danger" | "secondary";
}

export const QUEUE_BUTTON_DEFS: QueueButtonDef[] = [
  { key: "gelo_normal", defaultName: "Gelo Normal", defaultColor: "primary" },
  { key: "gelo_infinito", defaultName: "Gelo Infinito", defaultColor: "success" },
  { key: "full_ump_xm8", defaultName: "Full UMP e XM8", defaultColor: "danger" },
  { key: "entrar_fila", defaultName: "Entrar na Fila", defaultColor: "primary" },
  { key: "1emu", defaultName: "1 Emu", defaultColor: "secondary" },
  { key: "2emu", defaultName: "2 Emu", defaultColor: "secondary" },
  { key: "3emu", defaultName: "3 Emu", defaultColor: "secondary" },
];

export function findButtonDef(key: string): QueueButtonDef | undefined {
  return QUEUE_BUTTON_DEFS.find((b) => b.key === key);
}

export interface BotButtonDef {
  key: string;
  defaultName: string;
  defaultColor: "primary" | "success" | "danger" | "secondary";
  category: string;
}

export const BOT_BUTTON_DEFS: BotButtonDef[] = [
  { key: "apar_nome", defaultName: "Editar nome", defaultColor: "primary", category: "Aparência" },
  { key: "apar_banner", defaultName: "Editar banner", defaultColor: "success", category: "Aparência" },
  { key: "apar_thumb", defaultName: "Editar thumbnail", defaultColor: "danger", category: "Aparência" },
  { key: "apar_bio", defaultName: "Editar bio", defaultColor: "primary", category: "Aparência" },
  { key: "apar_status", defaultName: "Editar status", defaultColor: "success", category: "Aparência" },

  { key: "cfg_cargo_med", defaultName: "Cargo mediador", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_cargo_admin", defaultName: "Cargo admin", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_cargo_analista", defaultName: "Cargo analista", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_taxa", defaultName: "Taxa", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_aviso", defaultName: "Aviso", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_qrcolor", defaultName: "Cor do QR Code", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_qrborder", defaultName: "Borda do QR Code", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_canal", defaultName: "Canal de partidas", defaultColor: "secondary", category: "Configurações" },
  { key: "cfg_coins", defaultName: "Coins", defaultColor: "secondary", category: "Configurações" },

  { key: "filas_titulo", defaultName: "Título", defaultColor: "primary", category: "Filas" },
  { key: "filas_valores", defaultName: "Valores", defaultColor: "success", category: "Filas" },
  { key: "filas_banner", defaultName: "Banner", defaultColor: "danger", category: "Filas" },
  { key: "filas_thumb", defaultName: "Thumbnail", defaultColor: "primary", category: "Filas" },
  { key: "filas_enviar", defaultName: "Enviar filas", defaultColor: "success", category: "Filas" },

  { key: "med_pix", defaultName: "Configurar PIX", defaultColor: "primary", category: "Mediador" },
  { key: "med_entrar", defaultName: "Entrar na fila", defaultColor: "success", category: "Mediador" },
  { key: "med_sair", defaultName: "Sair", defaultColor: "danger", category: "Mediador" },
  { key: "med_lib_qr", defaultName: "Liberar QR Code", defaultColor: "primary", category: "Mediador" },
  { key: "med_lib_chave", defaultName: "Liberar chave PIX", defaultColor: "success", category: "Mediador" },
  { key: "med_def_vencedor", defaultName: "Definir vencedor", defaultColor: "danger", category: "Mediador" },
  { key: "med_chamar_analista", defaultName: "Chamar analista", defaultColor: "primary", category: "Mediador" },

  { key: "anal_entrar", defaultName: "Entrar na fila", defaultColor: "success", category: "Analista" },
  { key: "anal_sair", defaultName: "Sair", defaultColor: "danger", category: "Analista" },

  { key: "match_confirm", defaultName: "Confirmar", defaultColor: "success", category: "Partida" },
  { key: "match_cancel", defaultName: "Cancelar", defaultColor: "danger", category: "Partida" },

  { key: "criarorg_confirm", defaultName: "CONFIRMAR", defaultColor: "danger", category: "Servidor" },
  { key: "criarorg_cancel", defaultName: "Cancelar", defaultColor: "secondary", category: "Servidor" },

  { key: "fila_sair", defaultName: "Sair da fila", defaultColor: "secondary", category: "Botões de Fila" },
  { key: "filas_preview", defaultName: "Visualizar", defaultColor: "secondary", category: "Filas" },

  { key: "loja_add", defaultName: "Adicionar", defaultColor: "success", category: "Loja" },
  { key: "loja_rem", defaultName: "Remover", defaultColor: "danger", category: "Loja" },
  { key: "loja_edit", defaultName: "Editar", defaultColor: "primary", category: "Loja" },
  { key: "loja_ver", defaultName: "Ver prêmios", defaultColor: "secondary", category: "Loja" },
  { key: "loja_img", defaultName: "Imagens", defaultColor: "primary", category: "Loja" },
  { key: "loja_send", defaultName: "Enviar prêmio", defaultColor: "success", category: "Loja" },

  ...QUEUE_BUTTON_DEFS.map((b) => ({
    key: b.key,
    defaultName: b.defaultName,
    defaultColor: b.defaultColor,
    category: "Botões de Fila",
  })),
];

export function findBotButtonDef(key: string): BotButtonDef | undefined {
  return BOT_BUTTON_DEFS.find((b) => b.key === key);
}

export function botButtonCategories(): string[] {
  return [...new Set(BOT_BUTTON_DEFS.map((b) => b.category))];
}
