import {
  type Message,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  EmbedBuilder,
} from "discord.js";
import { isBotAdmin } from "../lib/permissions";
import { buildEmbedFromKey } from "../ui/embedHelper";
import { buildAdmCategorySelect, buildAdmEmbedSelect } from "./componentRouter";

const PREFIX = "!";

export async function handleMessage(msg: Message): Promise<void> {
  if (msg.author.bot) return;
  if (!msg.guild) return;
  if (!msg.content.startsWith(PREFIX)) return;

  const member = await msg.guild.members.fetch(msg.author.id).catch(() => null);
  const admin = await isBotAdmin(member);
  const args = msg.content.slice(PREFIX.length).trim().split(/\s+/);
  const command = (args.shift() ?? "").toLowerCase();

  if (!admin) {
    await msg.reply({ content: "❌ Apenas administradores do bot podem usar comandos com prefixo `!`." });
    return;
  }

  if (command === "ping") {
    return handlePing(msg);
  }

  if (command === "editar" && (args[0]?.toLowerCase() === "botões" || args[0]?.toLowerCase() === "botoes")) {
    return handleEditarBotoes(msg);
  }

  if (command === "editar" && args[0]?.toLowerCase() === "embed") {
    return handleEditarEmbed(msg);
  }

  await msg.reply({ content: "❌ Comando desconhecido. Tente `!ping`, `!editar botões` ou `!editar embed`." });
}

async function handlePing(msg: Message): Promise<void> {
  const sent = await msg.reply({ content: "🏓 Calculando latência..." });
  const apiPing = sent.createdTimestamp - msg.createdTimestamp;
  const wsPing = msg.client.ws.ping;
  const status =
    wsPing < 100 ? "🟢 Excelente" : wsPing < 250 ? "🟡 Estável" : wsPing < 500 ? "🟠 Lento" : "🔴 Crítico";

  const embed = await buildEmbedFromKey("ping", {
    description: [
      "Tudo certo por aqui! Aqui estão os números atuais da conexão entre o bot e o Discord.",
      "",
      `📡 **Latência da API:** \`${apiPing}ms\``,
      `🛰️ **Latência do WebSocket:** \`${wsPing}ms\``,
      `📊 **Status:** ${status}`,
      "",
      "✨ Quanto menor o valor, mais rápido o bot responde aos comandos.",
    ].join("\n"),
  });
  embed.setTimestamp();

  await sent.edit({ content: null, embeds: [embed] });
}

async function handleEditarBotoes(msg: Message): Promise<void> {
  const embed = await buildEmbedFromKey("editor_botoes", {
    description: [
      "Use o menu abaixo para escolher uma **categoria** e depois o **botão** que quer editar.",
      "",
      "Você pode mudar **nome, cor e emoji** de qualquer botão do bot.",
    ].join("\n"),
  });

  const catRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(buildAdmCategorySelect());
  await msg.reply({ embeds: [embed], components: [catRow] });
}

async function handleEditarEmbed(msg: Message): Promise<void> {
  const embed = await buildEmbedFromKey("editor_embeds", {
    description: [
      "Use o menu abaixo para escolher um **embed** e editar **título, descrição, cor e rodapé**.",
      "",
      "As mudanças aplicam-se em **tempo real** nos próximos painéis enviados (e nas filas ativas).",
    ].join("\n"),
  });

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(buildAdmEmbedSelect());
  await msg.reply({ embeds: [embed], components: [row] });
}

void EmbedBuilder;
