import {
  type ButtonInteraction,
  ChannelType,
  PermissionFlagsBits,
  type GuildBasedChannel,
  type Role,
} from "discord.js";
import { SERVER_CATEGORIES, SERVER_ROLES } from "../data/serverStructure";
import { logger } from "../../lib/logger";

export async function recreateServer(interaction: ButtonInteraction): Promise<void> {
  if (!interaction.guild) {
    await interaction.reply({ content: "Este comando só pode ser usado em servidores.", ephemeral: true });
    return;
  }
  await interaction.deferReply({ ephemeral: true });
  const guild = interaction.guild;

  try {
    await guild.channels.fetch();
    const everyone = guild.roles.everyone;

    for (const channel of [...guild.channels.cache.values()]) {
      try {
        await (channel as GuildBasedChannel).delete("Recriação de servidor via /criar org");
      } catch (err) {
        logger.warn({ err, channel: channel.name }, "Falha ao deletar canal");
      }
    }

    await guild.roles.fetch();
    for (const role of [...guild.roles.cache.values()]) {
      if (role.id === everyone.id) continue;
      if (role.managed) continue;
      const me = guild.members.me;
      if (me && me.roles.highest.position <= role.position) continue;
      try {
        await role.delete("Recriação de servidor via /criar org");
      } catch (err) {
        logger.warn({ err, role: role.name }, "Falha ao deletar cargo");
      }
    }

    const createdRoles = new Map<string, Role>();
    for (const def of SERVER_ROLES) {
      const role = await guild.roles.create({
        name: def.name,
        hoist: def.hoist,
        permissions: def.permissions,
        color: def.color,
        reason: "Recriação de servidor",
      });
      createdRoles.set(def.name.replace(/[^A-Z]/g, ""), role);
    }

    const teamRoleNames = ["DONO", "MEDIADOR", "ANALISTA", "SUPORTE"];

    for (const cat of SERVER_CATEGORIES) {
      const isPrivate = Boolean(cat.privateRoles && cat.privateRoles.length > 0);
      const overwrites = isPrivate
        ? [
            {
              id: everyone.id,
              deny: [PermissionFlagsBits.ViewChannel],
            },
            ...teamRoleNames
              .map((rn) => createdRoles.get(rn))
              .filter((r): r is Role => Boolean(r))
              .map((r) => ({
                id: r.id,
                allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
              })),
          ]
        : undefined;

      const category = await guild.channels.create({
        name: cat.name,
        type: ChannelType.GuildCategory,
        permissionOverwrites: overwrites,
      });

      for (const ch of cat.channels) {
        const chOverwrites = ch.private
          ? [
              { id: everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
              ...teamRoleNames
                .map((rn) => createdRoles.get(rn))
                .filter((r): r is Role => Boolean(r))
                .map((r) => ({
                  id: r.id,
                  allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
                })),
            ]
          : undefined;
        const channelType = ch.type === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText;
        await guild.channels.create({
          name: ch.name,
          type: channelType,
          parent: category.id,
          permissionOverwrites: chOverwrites,
        });
      }
    }

    await interaction.editReply({
      content: "✅ Servidor recriado com sucesso! Categorias, canais e cargos foram criados.",
    });
  } catch (err) {
    logger.error({ err }, "Erro ao recriar servidor");
    await interaction.editReply({ content: "❌ Erro ao recriar o servidor. Verifique se eu tenho permissão de **Administrador**." });
  }
}
