import {
  type ChatInputCommandInteraction,
  type GuildMember,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
} from "discord.js";
import { isBotAdmin } from "../lib/permissions";
import {
  ensureGuildSettings,
  listMediatorsInQueue,
  listAnalystsInQueue,
  listShopItems,
  getShopAppearance,
} from "../lib/store";
import { QUEUE_BUTTON_DEFS } from "../data/buttonsCatalog";
import { buildEmbedFromKey } from "../ui/embedHelper";
import { buildBotButton } from "../ui/buttonHelper";

export async function handleSlashCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const name = interaction.commandName;
  const sub = interaction.options.getSubcommand(false);

  if (name === "comandos") return cmdComandos(interaction);
  if (name === "bot" && sub === "aparencia") return cmdBotAparencia(interaction);
  if (name === "criar" && sub === "org") return cmdCriarOrg(interaction);
  if (name === "botões") return cmdBotoes(interaction);
  if (name === "configurações") return cmdConfiguracoes(interaction);
  if (name === "filas") return cmdFilas(interaction);
  if (name === "fila" && sub === "mediador") return cmdFilaMediador(interaction);
  if (name === "fila" && sub === "analista") return cmdFilaAnalista(interaction);
  if (name === "sala") return cmdSala(interaction);
  if (name === "loja" && sub === "coins") return cmdLojaCoins(interaction);

  await interaction.reply({ content: "Comando não reconhecido.", ephemeral: true });
}

async function cmdLojaCoins(interaction: ChatInputCommandInteraction): Promise<void> {
  const items = await listShopItems(interaction.guildId!);
  const appearance = await getShopAppearance(interaction.guildId!);

  const embed = await buildEmbedFromKey("loja_coins", {
    description: [
      "**Loja de prêmios** — administre os prêmios que podem ser trocados por coins.",
      "",
      `**Prêmios cadastrados:** ${items.length}`,
      `**Banner:** ${appearance.banner ? "definido" : "não definido"}`,
      `**Thumbnail:** ${appearance.thumb ? "definido" : "não definido"}`,
    ].join("\n"),
  });
  if (appearance.banner) embed.setImage(appearance.banner);
  if (appearance.thumb) embed.setThumbnail(appearance.thumb);

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("loja_add", { label: "Adicionar", style: ButtonStyle.Success }),
    await buildBotButton("loja_rem", { label: "Remover", style: ButtonStyle.Danger }),
    await buildBotButton("loja_edit", { label: "Editar", style: ButtonStyle.Primary }),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("loja_ver", { label: "Ver prêmios", style: ButtonStyle.Secondary }),
    await buildBotButton("loja_img", { label: "Imagens", style: ButtonStyle.Primary }),
    await buildBotButton("loja_send", { label: "Enviar prêmio", style: ButtonStyle.Success }),
  );

  await interaction.reply({ embeds: [embed], components: [row1, row2], ephemeral: true });
}

async function cmdComandos(interaction: ChatInputCommandInteraction): Promise<void> {
  const description = [
    "Aqui está tudo que o bot pode fazer. Use o comando indicado para abrir cada painel.",
    "",
    "**Comandos Slash (`/`)**",
    "🎮 `/comandos` — mostra este painel.",
    "🎨 `/bot aparencia` — edita nome, banner, thumbnail, bio e status do bot.",
    "🏗️ `/criar org` — recria todo o servidor com a estrutura padrão de filas.",
    "🔘 `/botões` — edita os botões usados nas filas.",
    "⚙️ `/configurações` — define cargos, taxa, canais, cores e coins.",
    "📊 `/filas` — configura e envia as embeds de filas.",
    "🤝 `/fila mediador` — painel de mediadores (PIX, entrar, sair).",
    "🔍 `/fila analista` — painel de analistas (entrar, sair).",
    "🏠 `/sala` — envia o ID e a senha de uma sala personalizada.",
    "",
    "**Comandos com prefixo `!` (somente administradores do bot)**",
    "🏓 `!ping` — mostra a latência do bot.",
    "✏️ `!editar botões` — edita nome, cor e emoji de todos os botões do bot.",
    "📝 `!editar embed` — edita título, descrição e cor de todos os embeds do bot.",
  ].join("\n");

  const embed = await buildEmbedFromKey("comandos", { description });
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function cmdBotAparencia(interaction: ChatInputCommandInteraction): Promise<void> {
  const embed = await buildEmbedFromKey("bot_aparencia", {
    description:
      "Edite o **nome**, **banner**, **thumbnail**, **bio** e **status** do bot. Bio e status valem para o bot inteiro; nome, banner e thumbnail valem só neste servidor.",
  });

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("apar_nome", { label: "Editar nome", style: ButtonStyle.Primary }),
    await buildBotButton("apar_banner", { label: "Editar banner", style: ButtonStyle.Success }),
    await buildBotButton("apar_thumb", { label: "Editar thumbnail", style: ButtonStyle.Danger }),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("apar_bio", { label: "Editar bio", style: ButtonStyle.Primary }),
    await buildBotButton("apar_status", { label: "Editar status", style: ButtonStyle.Success }),
  );

  await interaction.reply({ embeds: [embed], components: [row1, row2], ephemeral: true });
}

async function cmdCriarOrg(interaction: ChatInputCommandInteraction): Promise<void> {
  const member = await interaction.guild?.members.fetch(interaction.user.id).catch(() => null);
  const isAdmin = await isBotAdmin(member as GuildMember | null);
  if (!isAdmin) {
    await interaction.reply({ content: "❌ Você precisa ser administrador do bot para usar este comando.", ephemeral: true });
    return;
  }
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("criarorg_confirm", { label: "CONFIRMAR", style: ButtonStyle.Danger }),
    await buildBotButton("criarorg_cancel", { label: "Cancelar", style: ButtonStyle.Secondary }),
  );
  await interaction.reply({
    content:
      "⚠️ **ATENÇÃO!** Isso irá apagar **todos os canais e cargos personalizados** do servidor e recriar a estrutura padrão de filas.\n\nClique em **CONFIRMAR** para continuar.",
    components: [row],
    ephemeral: true,
  });
}

async function cmdBotoes(interaction: ChatInputCommandInteraction): Promise<void> {
  const embed = await buildEmbedFromKey("editor_botoes", {
    description: "Use o menu abaixo para escolher um botão e editar **nome, cor e emoji**.",
  });
  const select = new StringSelectMenuBuilder()
    .setCustomId("guild_btn_pick")
    .setPlaceholder("Escolha um botão da fila para editar")
    .addOptions(
      QUEUE_BUTTON_DEFS.slice(0, 25).map((b) => ({
        label: b.defaultName.slice(0, 100),
        value: b.key,
      })),
    );
  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function cmdConfiguracoes(interaction: ChatInputCommandInteraction): Promise<void> {
  await ensureGuildSettings(interaction.guildId!);
  const embed = await buildEmbedFromKey("configuracoes", {
    description: [
      "Use os botões abaixo para configurar o bot. Cada configuração é salva automaticamente.",
      "",
      "🎭 Cargos · 💰 Taxa · 📢 Aviso · 🎨 Cores QR · 📺 Canal · 🪙 Coins",
    ].join("\n"),
  });

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("cfg_cargo_med", { label: "Cargo mediador", style: ButtonStyle.Secondary }),
    await buildBotButton("cfg_cargo_admin", { label: "Cargo admin", style: ButtonStyle.Secondary }),
    await buildBotButton("cfg_cargo_analista", { label: "Cargo analista", style: ButtonStyle.Secondary }),
    await buildBotButton("cfg_taxa", { label: "Taxa", style: ButtonStyle.Secondary }),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("cfg_aviso", { label: "Aviso", style: ButtonStyle.Secondary }),
    await buildBotButton("cfg_qrcolor", { label: "Cor do QR Code", style: ButtonStyle.Secondary }),
    await buildBotButton("cfg_qrborder", { label: "Borda do QR Code", style: ButtonStyle.Secondary }),
    await buildBotButton("cfg_canal", { label: "Canal de partidas", style: ButtonStyle.Secondary }),
  );
  const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("cfg_coins", { label: "Coins", style: ButtonStyle.Secondary }),
  );

  await interaction.reply({ embeds: [embed], components: [row1, row2, row3], ephemeral: true });
}

async function cmdFilas(interaction: ChatInputCommandInteraction): Promise<void> {
  const s = await ensureGuildSettings(interaction.guildId!);
  const enabled = (s.fila_botoes ?? "").split(",").filter(Boolean);

  const embed = await buildEmbedFromKey("filas_painel", {
    description: [
      `**Título:** ${s.fila_titulo ?? "FILA"}`,
      `**Modo:** ${s.fila_modo ?? "1v1"}`,
      `**Tipo:** ${s.fila_tipo ?? "mobile"}`,
      `**Valores:** ${s.fila_valores ?? "0.50"}`,
      `**Botões ativos:** ${enabled.length}`,
      "",
      "Use os menus abaixo para configurar e o botão verde para enviar.",
    ].join("\n"),
  });

  const modoSelect = new StringSelectMenuBuilder()
    .setCustomId("filas_modo_select")
    .setPlaceholder(`Modo (atual: ${s.fila_modo ?? "1v1"})`)
    .addOptions(
      { label: "1v1", value: "1v1", default: (s.fila_modo ?? "1v1") === "1v1" },
      { label: "2v2", value: "2v2", default: s.fila_modo === "2v2" },
      { label: "3v3", value: "3v3", default: s.fila_modo === "3v3" },
      { label: "4v4", value: "4v4", default: s.fila_modo === "4v4" },
    );
  const tipoSelect = new StringSelectMenuBuilder()
    .setCustomId("filas_tipo_select")
    .setPlaceholder(`Tipo (atual: ${s.fila_tipo ?? "mobile"})`)
    .addOptions(
      { label: "Mobile", value: "mobile", default: (s.fila_tipo ?? "mobile") === "mobile" },
      { label: "Emulador", value: "emulador", default: s.fila_tipo === "emulador" },
      { label: "Misto", value: "misto", default: s.fila_tipo === "misto" },
    );
  const botoesSelect = new StringSelectMenuBuilder()
    .setCustomId("filas_botoes_select")
    .setPlaceholder("Botões ativos nas filas")
    .setMinValues(1)
    .setMaxValues(QUEUE_BUTTON_DEFS.length)
    .addOptions(
      QUEUE_BUTTON_DEFS.map((b) => ({
        label: b.defaultName,
        value: b.key,
        default: enabled.includes(b.key),
      })),
    );

  const rowModo = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(modoSelect);
  const rowTipo = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(tipoSelect);
  const rowBotoes = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(botoesSelect);

  const rowOptions = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("filas_titulo", { label: "Título", style: ButtonStyle.Primary }),
    await buildBotButton("filas_valores", { label: "Valores", style: ButtonStyle.Success }),
    await buildBotButton("filas_banner", { label: "Banner", style: ButtonStyle.Danger }),
    await buildBotButton("filas_thumb", { label: "Thumbnail", style: ButtonStyle.Primary }),
  );
  const rowSend = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("filas_preview", { label: "Visualizar", style: ButtonStyle.Secondary }),
    await buildBotButton("filas_enviar", { label: "Enviar filas", style: ButtonStyle.Success }),
  );

  await interaction.reply({
    embeds: [embed],
    components: [rowModo, rowTipo, rowBotoes, rowOptions, rowSend],
    ephemeral: true,
  });
}

async function cmdFilaMediador(interaction: ChatInputCommandInteraction): Promise<void> {
  await ensureGuildSettings(interaction.guildId!);
  const inQueue = await listMediatorsInQueue(interaction.guildId!);

  const lines = ["**Mediadores na fila:**"];
  if (inQueue.length === 0) lines.push("_Nenhum mediador na fila no momento._");
  else inQueue.forEach((id, i) => lines.push(`${i + 1}. <@${id}>`));

  const embed = await buildEmbedFromKey("fila_mediador", {
    description: [
      "Mediadores podem configurar seu PIX e entrar na fila para serem chamados em partidas.",
      "",
      ...lines,
    ].join("\n"),
  });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("med_pix", { label: "Configurar PIX", style: ButtonStyle.Primary }),
    await buildBotButton("med_entrar", { label: "Entrar na fila", style: ButtonStyle.Success }),
    await buildBotButton("med_sair", { label: "Sair", style: ButtonStyle.Danger }),
  );

  await interaction.reply({ embeds: [embed], components: [row] });
}

async function cmdFilaAnalista(interaction: ChatInputCommandInteraction): Promise<void> {
  await ensureGuildSettings(interaction.guildId!);
  const inQueue = await listAnalystsInQueue(interaction.guildId!);

  const lines = ["**Analistas na fila:**"];
  if (inQueue.length === 0) lines.push("_Nenhum analista na fila no momento._");
  else inQueue.forEach((id, i) => lines.push(`${i + 1}. <@${id}>`));

  const embed = await buildEmbedFromKey("fila_analista", {
    description: [
      "Analistas entram na fila e podem ser chamados pelos mediadores no canal de partida.",
      "",
      ...lines,
    ].join("\n"),
  });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("anal_entrar", { label: "Entrar na fila", style: ButtonStyle.Success }),
    await buildBotButton("anal_sair", { label: "Sair", style: ButtonStyle.Danger }),
  );

  await interaction.reply({ embeds: [embed], components: [row] });
}

async function cmdSala(interaction: ChatInputCommandInteraction): Promise<void> {
  const modal = new ModalBuilder().setCustomId("sala_modal").setTitle("Sala personalizada");
  const id = new TextInputBuilder()
    .setCustomId("sala_id")
    .setLabel("ID da sala")
    .setStyle(TextInputStyle.Short)
    .setRequired(false);
  const senha = new TextInputBuilder()
    .setCustomId("sala_senha")
    .setLabel("Senha da sala")
    .setStyle(TextInputStyle.Short)
    .setRequired(false);
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(id),
    new ActionRowBuilder<TextInputBuilder>().addComponents(senha),
  );
  await interaction.showModal(modal);
}
