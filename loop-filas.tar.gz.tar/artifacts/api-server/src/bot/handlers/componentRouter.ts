import {
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type AnySelectMenuInteraction,
  type StringSelectMenuInteraction,
  type RoleSelectMenuInteraction,
  type ChannelSelectMenuInteraction,
  type UserSelectMenuInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  StringSelectMenuBuilder,
  UserSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits,
  AttachmentBuilder,
  ActivityType,
  type PresenceStatusData,
  type TextChannel,
  type GuildTextBasedChannel,
} from "discord.js";
import { isBotAdmin, isMediator } from "../lib/permissions";
import {
  ensureGuildSettings,
  updateGuildSettings,
  upsertQueueButton,
  upsertGlobalButton,
  getGlobalButton,
  getMediatorPix,
  setMediatorPix,
  addMediatorToQueue,
  removeMediatorFromQueue,
  popNextMediator,
  listMediatorsInQueue,
  addAnalystToQueue,
  removeAnalystFromQueue,
  listAnalystsInQueue,
  popNextAnalyst,
  recordMatch,
  addCoins,
  upsertEmbedOverride,
  getEmbedOverride,
  setBotAppearance,
  getBotAppearance,
  listShopItems,
  getShopItem,
  addShopItem,
  updateShopItem,
  removeShopItem,
  getShopAppearance,
  setShopAppearance,
} from "../lib/store";
import { findButtonDef, QUEUE_BUTTON_DEFS, BOT_BUTTON_DEFS, findBotButtonDef, botButtonCategories } from "../data/buttonsCatalog";
import { EMBED_DEFS, findEmbedDef } from "../data/embedsCatalog";
import { activeQueues, activeMatches } from "../state";
import { buildQueueEmbed, buildQueueButtonsRows, formatPrice } from "../ui/queueEmbed";
import { buildEmbedFromKey } from "../ui/embedHelper";
import { buildBotButton } from "../ui/buttonHelper";
import { generatePixQrPng } from "../lib/pix";
import { recreateServer } from "./recreateServer";
import { logger } from "../../lib/logger";

export const handleComponent = {
  button: handleButton,
  modal: handleModal,
  select: handleSelect,
};

async function handleButton(interaction: ButtonInteraction): Promise<void> {
  const id = interaction.customId;

  if (id === "criarorg_confirm") return recreateServer(interaction);
  if (id === "criarorg_cancel") {
    await interaction.update({ content: "Operação cancelada.", components: [] });
    return;
  }

  if (id === "apar_nome") return openSimpleModal(interaction, "apar_nome_modal", "Editar nome do bot", "Novo nome", "name", TextInputStyle.Short);
  if (id === "apar_banner") return openSimpleModal(interaction, "apar_banner_modal", "Editar banner", "URL do banner", "url", TextInputStyle.Short);
  if (id === "apar_thumb") return openSimpleModal(interaction, "apar_thumb_modal", "Editar thumbnail", "URL da thumbnail", "url", TextInputStyle.Short);
  if (id === "apar_bio") return openBioModal(interaction);
  if (id === "apar_status") return openStatusModal(interaction);

  if (id.startsWith("btn_edit:")) {
    const key = id.slice("btn_edit:".length);
    return openButtonEditModal(interaction, key, false);
  }
  if (id.startsWith("adm_btn_edit:")) {
    const key = id.slice("adm_btn_edit:".length);
    return openButtonEditModal(interaction, key, true);
  }

  if (id === "cfg_cargo_med" || id === "cfg_cargo_admin" || id === "cfg_cargo_analista") {
    const select = new RoleSelectMenuBuilder().setCustomId(`${id}_select`).setPlaceholder("Selecione o cargo").setMaxValues(1);
    await interaction.reply({ components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select)], ephemeral: true });
    return;
  }
  if (id === "cfg_canal") {
    const select = new ChannelSelectMenuBuilder()
      .setCustomId("cfg_canal_select")
      .setPlaceholder("Selecione o canal")
      .setChannelTypes(ChannelType.GuildText)
      .setMaxValues(1);
    await interaction.reply({ components: [new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select)], ephemeral: true });
    return;
  }
  if (id === "cfg_taxa") return openSimpleModal(interaction, "cfg_taxa_modal", "Definir taxa", "Taxa (use . para centavos abaixo de 1, ou , para 1,00+)", "taxa", TextInputStyle.Short);
  if (id === "cfg_aviso") return openSimpleModal(interaction, "cfg_aviso_modal", "Definir aviso", "Aviso enviado nos canais de partida", "aviso", TextInputStyle.Paragraph);
  if (id === "cfg_qrcolor") return openSimpleModal(interaction, "cfg_qrcolor_modal", "Cor do QR Code", "Código HEX (#000000)", "color", TextInputStyle.Short);
  if (id === "cfg_qrborder") return openSimpleModal(interaction, "cfg_qrborder_modal", "Borda do QR Code", "Código HEX (#FFFFFF)", "color", TextInputStyle.Short);
  if (id === "cfg_coins") {
    const modal = new ModalBuilder().setCustomId("cfg_coins_modal").setTitle("Coins por partida");
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("winner").setLabel("Coins do vencedor").setStyle(TextInputStyle.Short).setRequired(false),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("loser").setLabel("Coins do perdedor").setStyle(TextInputStyle.Short).setRequired(false),
      ),
    );
    await interaction.showModal(modal);
    return;
  }

  if (id === "filas_titulo") return openSimpleModal(interaction, "filas_titulo_modal", "Título das filas", "Título", "v", TextInputStyle.Short);
  if (id === "filas_valores") return openSimpleModal(interaction, "filas_valores_modal", "Valores das filas", "Um valor por linha (ex: 0.50, 1,00)", "v", TextInputStyle.Paragraph);
  if (id === "filas_banner") return openSimpleModal(interaction, "filas_banner_modal", "Banner das filas", "URL (suporta gif)", "v", TextInputStyle.Short);
  if (id === "filas_thumb") return openSimpleModal(interaction, "filas_thumb_modal", "Thumbnail das filas", "URL (suporta gif)", "v", TextInputStyle.Short);
  if (id === "filas_enviar") return enviarFilas(interaction);
  if (id === "filas_preview") return previewFilas(interaction);

  if (id === "loja_add") return openLojaAddModal(interaction);
  if (id === "loja_rem") return openLojaRemoverSelect(interaction);
  if (id === "loja_edit") return openLojaEditarSelect(interaction);
  if (id === "loja_ver") return mostrarLojaPremios(interaction);
  if (id === "loja_img") return openLojaImagensModal(interaction);
  if (id === "loja_send") return openLojaEnviarSelect(interaction);

  if (id === "med_pix") return openMediatorPixModal(interaction);
  if (id === "med_entrar") return mediatorEntrar(interaction);
  if (id === "med_sair") return mediatorSair(interaction);

  if (id === "anal_entrar") return analystEntrar(interaction);
  if (id === "anal_sair") return analystSair(interaction);

  if (id.startsWith("fila_join:")) {
    const [, key, price] = id.split(":");
    return filaJoin(interaction, key!, price!);
  }

  if (id === "fila_sair") return filaSair(interaction);

  if (id === "match_confirm") return matchConfirm(interaction);
  if (id === "match_cancel") return matchCancel(interaction);
  if (id === "med_lib_qr") return liberarQrCode(interaction);
  if (id === "med_lib_chave") return liberarChave(interaction);
  if (id === "med_def_vencedor") return abrirSelectVencedor(interaction);
  if (id === "med_chamar_analista") return chamarAnalista(interaction);

  await interaction.reply({ content: "Botão não reconhecido.", ephemeral: true });
}

async function openSimpleModal(
  interaction: ButtonInteraction,
  customId: string,
  title: string,
  label: string,
  fieldId: string,
  style: TextInputStyle,
): Promise<void> {
  const modal = new ModalBuilder().setCustomId(customId).setTitle(title);
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId(fieldId).setLabel(label.slice(0, 45)).setStyle(style).setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function openBioModal(interaction: ButtonInteraction): Promise<void> {
  const current = await getBotAppearance();
  const modal = new ModalBuilder().setCustomId("apar_bio_modal").setTitle("Editar bio do bot");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("bio")
        .setLabel("Bio (até 400 caracteres)")
        .setStyle(TextInputStyle.Paragraph)
        .setMaxLength(400)
        .setValue(current.bio ?? "")
        .setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function openStatusModal(interaction: ButtonInteraction): Promise<void> {
  const current = await getBotAppearance();
  const modal = new ModalBuilder().setCustomId("apar_status_modal").setTitle("Editar status do bot");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("status_text")
        .setLabel("Texto do status")
        .setStyle(TextInputStyle.Short)
        .setValue(current.status_text ?? "")
        .setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("status_type")
        .setLabel("Tipo (jogando, ouvindo, assistindo, competindo)")
        .setStyle(TextInputStyle.Short)
        .setValue(current.status_type ?? "PLAYING")
        .setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("status_presence")
        .setLabel("Presença (online, idle, dnd, invisible)")
        .setStyle(TextInputStyle.Short)
        .setValue(current.status_presence ?? "online")
        .setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function openButtonEditModal(interaction: ButtonInteraction, buttonKey: string, isAdmin: boolean): Promise<void> {
  if (isAdmin) {
    const member = interaction.member;
    const ok = await isBotAdmin(member as never);
    if (!ok) {
      await interaction.reply({ content: "❌ Apenas administradores do bot.", ephemeral: true });
      return;
    }
  }
  const def = findBotButtonDef(buttonKey) ?? findButtonDef(buttonKey);
  const existing = isAdmin ? await getGlobalButton(buttonKey) : null;
  const modal = new ModalBuilder()
    .setCustomId((isAdmin ? "adm_btn_edit_modal:" : "btn_edit_modal:") + buttonKey)
    .setTitle(`Editar: ${def?.defaultName ?? buttonKey}`.slice(0, 45));
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId("name").setLabel("Nome do botão").setStyle(TextInputStyle.Short).setValue(existing?.name ?? "").setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId("color").setLabel("Cor (azul, verde, vermelho, cinza)").setStyle(TextInputStyle.Short).setValue(existing?.color ?? "").setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId("emoji").setLabel("Emoji (ID, código <:nome:id> ou unicode)").setStyle(TextInputStyle.Short).setValue(existing?.emoji ?? "").setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function openEmbedEditModal(interaction: ButtonInteraction | StringSelectMenuInteraction, key: string): Promise<void> {
  const def = findEmbedDef(key);
  const existing = await getEmbedOverride(key);
  const modal = new ModalBuilder()
    .setCustomId(`embed_edit_modal:${key}`)
    .setTitle(`Editar: ${def?.label ?? key}`.slice(0, 45));
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("title")
        .setLabel("Título")
        .setStyle(TextInputStyle.Short)
        .setValue(existing?.title ?? def?.defaultTitle ?? "")
        .setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("description")
        .setLabel("Descrição")
        .setStyle(TextInputStyle.Paragraph)
        .setValue(existing?.description ?? def?.defaultDescription ?? "")
        .setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("color")
        .setLabel("Cor (HEX, ex: #5865F2)")
        .setStyle(TextInputStyle.Short)
        .setValue(existing?.color ?? def?.defaultColor ?? "")
        .setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("footer")
        .setLabel("Rodapé")
        .setStyle(TextInputStyle.Short)
        .setValue(existing?.footer ?? def?.defaultFooter ?? "")
        .setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function handleModal(interaction: ModalSubmitInteraction): Promise<void> {
  const id = interaction.customId;
  const guildId = interaction.guildId!;

  if (id === "sala_modal") {
    const sid = interaction.fields.getTextInputValue("sala_id");
    const senha = interaction.fields.getTextInputValue("sala_senha");
    const embed = await buildEmbedFromKey("sala", {
      description: [
        "📌 As informações da sala foram divulgadas! Entrem com calma e respeitem as regras.",
        "",
        `🆔 **ID da sala:** \`${sid || "—"}\``,
        `🔑 **Senha:** \`${senha || "—"}\``,
        "",
        "🎮 Boa partida a todos!",
      ].join("\n"),
      footer: `Sala criada por ${interaction.user.username}`,
    });
    await interaction.reply({ embeds: [embed.setTimestamp()] });
    return;
  }

  if (id === "apar_nome_modal") {
    const v = interaction.fields.getTextInputValue("name");
    try {
      await interaction.guild?.members.me?.setNickname(v || null);
      await updateGuildSettings(guildId, { bot_nickname: v || null });
      await interaction.reply({ content: `✅ Nome do bot atualizado para **${v || "padrão"}**.`, ephemeral: true });
    } catch (err) {
      await interaction.reply({ content: `❌ Não consegui mudar o nome: ${(err as Error).message}`, ephemeral: true });
    }
    return;
  }
  if (id === "apar_banner_modal") {
    const v = interaction.fields.getTextInputValue("url");
    await updateGuildSettings(guildId, { bot_banner: v || null });
    await interaction.reply({ content: `✅ Banner salvo. ${v ? "" : "(removido)"}`, ephemeral: true });
    return;
  }
  if (id === "apar_thumb_modal") {
    const v = interaction.fields.getTextInputValue("url");
    await updateGuildSettings(guildId, { bot_thumb: v || null });
    await interaction.reply({ content: `✅ Thumbnail salva.`, ephemeral: true });
    return;
  }
  if (id === "apar_bio_modal") {
    const v = interaction.fields.getTextInputValue("bio");
    try {
      if (interaction.client.application) {
        await interaction.client.application.edit({ description: v || "" });
      }
      await setBotAppearance({ bio: v || null });
      await interaction.reply({ content: `✅ Bio do bot atualizada.`, ephemeral: true });
    } catch (err) {
      await interaction.reply({ content: `❌ Não consegui salvar a bio: ${(err as Error).message}`, ephemeral: true });
    }
    return;
  }
  if (id === "apar_status_modal") {
    const text = interaction.fields.getTextInputValue("status_text").trim();
    const typeRaw = interaction.fields.getTextInputValue("status_type").trim().toLowerCase();
    const presenceRaw = interaction.fields.getTextInputValue("status_presence").trim().toLowerCase();

    const typeMap: Record<string, ActivityType> = {
      jogando: ActivityType.Playing,
      playing: ActivityType.Playing,
      ouvindo: ActivityType.Listening,
      listening: ActivityType.Listening,
      assistindo: ActivityType.Watching,
      watching: ActivityType.Watching,
      competindo: ActivityType.Competing,
      competing: ActivityType.Competing,
      streaming: ActivityType.Streaming,
    };
    const presenceMap: Record<string, PresenceStatusData> = {
      online: "online",
      idle: "idle",
      ausente: "idle",
      dnd: "dnd",
      ocupado: "dnd",
      invisible: "invisible",
      invisivel: "invisible",
    };

    const activityType = typeMap[typeRaw] ?? ActivityType.Playing;
    const status: PresenceStatusData = presenceMap[presenceRaw] ?? "online";

    try {
      interaction.client.user?.setPresence({
        activities: text ? [{ name: text, type: activityType }] : [],
        status,
      });
      await setBotAppearance({
        status_text: text || null,
        status_type: typeRaw.toUpperCase() || "PLAYING",
        status_presence: presenceRaw || "online",
      });
      await interaction.reply({ content: `✅ Status atualizado.`, ephemeral: true });
    } catch (err) {
      await interaction.reply({ content: `❌ Erro ao atualizar status: ${(err as Error).message}`, ephemeral: true });
    }
    return;
  }

  if (id.startsWith("btn_edit_modal:") || id.startsWith("adm_btn_edit_modal:")) {
    const isAdmin = id.startsWith("adm_btn_edit_modal:");
    const key = id.split(":")[1]!;
    const name = interaction.fields.getTextInputValue("name").trim();
    const color = interaction.fields.getTextInputValue("color").trim();
    const emoji = interaction.fields.getTextInputValue("emoji").trim();
    const patch = {
      ...(name ? { name } : {}),
      ...(color ? { color } : {}),
      ...(emoji ? { emoji } : { emoji: null }),
    };
    if (isAdmin) await upsertGlobalButton(key, patch);
    else await upsertQueueButton(guildId, key, patch);
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Botão **${key}** atualizado.`, ephemeral: true });
    return;
  }

  if (id.startsWith("embed_edit_modal:")) {
    const key = id.split(":")[1]!;
    const title = interaction.fields.getTextInputValue("title").trim();
    const description = interaction.fields.getTextInputValue("description").trim();
    const color = interaction.fields.getTextInputValue("color").trim();
    const footer = interaction.fields.getTextInputValue("footer").trim();
    await upsertEmbedOverride(key, {
      title: title || null,
      description: description || null,
      color: color || null,
      footer: footer || null,
    });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Embed **${key}** atualizado.`, ephemeral: true });
    return;
  }

  if (id === "cfg_taxa_modal") {
    const v = interaction.fields.getTextInputValue("taxa").trim();
    const num = Number(v.replace(",", "."));
    if (Number.isNaN(num)) {
      await interaction.reply({ content: "❌ Valor inválido.", ephemeral: true });
      return;
    }
    await updateGuildSettings(guildId, { taxa: String(num) as never });
    await interaction.reply({ content: `✅ Taxa definida como **${formatTaxa(num)}**.`, ephemeral: true });
    return;
  }
  if (id === "cfg_aviso_modal") {
    const v = interaction.fields.getTextInputValue("aviso");
    await updateGuildSettings(guildId, { aviso: v || null });
    await interaction.reply({ content: `✅ Aviso salvo.`, ephemeral: true });
    return;
  }
  if (id === "cfg_qrcolor_modal") {
    const v = interaction.fields.getTextInputValue("color");
    await updateGuildSettings(guildId, { qr_color: v || "#000000" });
    await interaction.reply({ content: `✅ Cor do QR salva: \`${v || "#000000"}\``, ephemeral: true });
    return;
  }
  if (id === "cfg_qrborder_modal") {
    const v = interaction.fields.getTextInputValue("color");
    await updateGuildSettings(guildId, { qr_border_color: v || "#FFFFFF" });
    await interaction.reply({ content: `✅ Borda do QR salva: \`${v || "#FFFFFF"}\``, ephemeral: true });
    return;
  }
  if (id === "cfg_coins_modal") {
    const w = Number(interaction.fields.getTextInputValue("winner") || 10);
    const l = Number(interaction.fields.getTextInputValue("loser") || 2);
    await updateGuildSettings(guildId, { coin_winner: w, coin_loser: l });
    await interaction.reply({ content: `✅ Coins definidos: vencedor **${w}**, perdedor **${l}**.`, ephemeral: true });
    return;
  }

  if (id === "filas_titulo_modal") {
    const v = interaction.fields.getTextInputValue("v");
    await updateGuildSettings(guildId, { fila_titulo: v || "FILA" });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Título salvo: **${v || "FILA"}**`, ephemeral: true });
    return;
  }
  if (id === "filas_valores_modal") {
    const v = interaction.fields.getTextInputValue("v");
    const valores = v
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter((s) => isValidQueueValue(s))
      .join(",");
    await updateGuildSettings(guildId, { fila_valores: valores || "0.50" });
    await interaction.reply({ content: `✅ Valores salvos: \`${valores || "0.50"}\` (valores inválidos como "00" foram ignorados)`, ephemeral: true });
    return;
  }
  if (id === "filas_banner_modal") {
    const v = interaction.fields.getTextInputValue("v");
    await updateGuildSettings(guildId, { fila_banner: v || null });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Banner das filas salvo.`, ephemeral: true });
    return;
  }
  if (id === "filas_thumb_modal") {
    const v = interaction.fields.getTextInputValue("v");
    await updateGuildSettings(guildId, { fila_thumb: v || null });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Thumbnail das filas salva.`, ephemeral: true });
    return;
  }

  if (id === "med_pix_modal") {
    const chave = interaction.fields.getTextInputValue("chave").trim();
    const titular = interaction.fields.getTextInputValue("titular").trim();
    const cidade = interaction.fields.getTextInputValue("cidade").trim();
    if (!chave || !titular || !cidade) {
      await interaction.reply({ content: "❌ Preencha todos os campos.", ephemeral: true });
      return;
    }
    await setMediatorPix(guildId, interaction.user.id, { chave, titular, cidade });
    await interaction.reply({ content: `✅ PIX configurado com sucesso.`, ephemeral: true });
    return;
  }

  if (id === "loja_add_modal" || id.startsWith("loja_edit_modal:")) {
    return submitLojaItemModal(interaction);
  }
  if (id === "loja_img_modal") {
    return submitLojaImagensModal(interaction);
  }

  await interaction.reply({ content: "Modal não reconhecido.", ephemeral: true });
}

async function handleSelect(interaction: AnySelectMenuInteraction): Promise<void> {
  const id = interaction.customId;
  const guildId = interaction.guildId!;

  if (id === "cfg_cargo_med_select") {
    const r = (interaction as RoleSelectMenuInteraction).values[0]!;
    await updateGuildSettings(guildId, { cargo_mediador: r });
    await interaction.update({ content: `✅ Cargo de mediador definido: <@&${r}>`, components: [] });
    return;
  }
  if (id === "cfg_cargo_admin_select") {
    const r = (interaction as RoleSelectMenuInteraction).values[0]!;
    await updateGuildSettings(guildId, { cargo_admin: r });
    await interaction.update({ content: `✅ Cargo de admin definido: <@&${r}>`, components: [] });
    return;
  }
  if (id === "cfg_cargo_analista_select") {
    const r = (interaction as RoleSelectMenuInteraction).values[0]!;
    await updateGuildSettings(guildId, { cargo_analista: r });
    await interaction.update({ content: `✅ Cargo de analista definido: <@&${r}>`, components: [] });
    return;
  }
  if (id === "cfg_canal_select") {
    const c = (interaction as ChannelSelectMenuInteraction).values[0]!;
    await updateGuildSettings(guildId, { match_channel: c });
    await interaction.update({ content: `✅ Canal de partidas definido: <#${c}>`, components: [] });
    return;
  }

  if (id === "filas_modo_select") {
    const v = (interaction as StringSelectMenuInteraction).values[0]!;
    await updateGuildSettings(guildId, { fila_modo: v });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Modo definido: **${v}**`, ephemeral: true });
    return;
  }
  if (id === "filas_tipo_select") {
    const v = (interaction as StringSelectMenuInteraction).values[0]!;
    await updateGuildSettings(guildId, { fila_tipo: v });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Tipo definido: **${v}**`, ephemeral: true });
    return;
  }
  if (id === "filas_botoes_select") {
    const vals = (interaction as StringSelectMenuInteraction).values;
    await updateGuildSettings(guildId, { fila_botoes: vals.join(",") });
    await refreshActiveQueueMessages(interaction);
    await interaction.reply({ content: `✅ Botões selecionados: **${vals.length}**`, ephemeral: true });
    return;
  }

  if (id === "guild_btn_pick") {
    const key = (interaction as StringSelectMenuInteraction).values[0]!;
    const fakeBtn = interaction as unknown as ButtonInteraction;
    return openButtonEditModal(fakeBtn, key, false);
  }

  if (id === "adm_btn_cat") {
    const cat = (interaction as StringSelectMenuInteraction).values[0]!;
    const buttons = BOT_BUTTON_DEFS.filter((b) => b.category === cat).slice(0, 25);
    const select = new StringSelectMenuBuilder()
      .setCustomId("adm_btn_pick")
      .setPlaceholder(`Botões: ${cat}`)
      .addOptions(buttons.map((b) => ({ label: b.defaultName.slice(0, 100), value: b.key, description: b.key })));
    const back = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(buildAdmCategorySelect());
    const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
    await interaction.update({ components: [back, row] });
    return;
  }

  if (id === "adm_btn_pick") {
    const key = (interaction as StringSelectMenuInteraction).values[0]!;
    const fakeBtn = interaction as unknown as ButtonInteraction;
    return openButtonEditModal(fakeBtn, key, true);
  }

  if (id === "adm_embed_pick") {
    const key = (interaction as StringSelectMenuInteraction).values[0]!;
    return openEmbedEditModal(interaction as StringSelectMenuInteraction, key);
  }

  if (id.startsWith("def_vencedor_select:")) {
    const channelId = id.split(":")[1]!;
    const v = (interaction as StringSelectMenuInteraction).values[0]!;
    return definirVencedor(interaction as StringSelectMenuInteraction, channelId, v);
  }

  if (id === "loja_rem_select") {
    const v = (interaction as StringSelectMenuInteraction).values[0]!;
    const item = await getShopItem(Number(v));
    await removeShopItem(Number(v));
    await interaction.update({
      content: `✅ Prêmio **${item?.name ?? v}** removido.`,
      components: [],
    });
    return;
  }
  if (id === "loja_edit_select") {
    const v = (interaction as StringSelectMenuInteraction).values[0]!;
    return openLojaItemModal(interaction as StringSelectMenuInteraction, Number(v));
  }
  if (id === "loja_send_item_select") {
    const itemId = (interaction as StringSelectMenuInteraction).values[0]!;
    const userSelect = new UserSelectMenuBuilder()
      .setCustomId(`loja_send_user_select:${itemId}`)
      .setPlaceholder("Escolha o usuário que vai receber");
    await interaction.update({
      content: "Agora escolha o usuário que vai receber o prêmio:",
      components: [new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(userSelect)],
    });
    return;
  }
  if (id.startsWith("loja_send_user_select:")) {
    const itemId = Number(id.split(":")[1]);
    const userId = (interaction as UserSelectMenuInteraction).values[0]!;
    return enviarPremio(interaction as UserSelectMenuInteraction, itemId, userId);
  }

  await interaction.reply({ content: "Select não reconhecido.", ephemeral: true });
}

export function buildAdmCategorySelect(): StringSelectMenuBuilder {
  return new StringSelectMenuBuilder()
    .setCustomId("adm_btn_cat")
    .setPlaceholder("Escolha a categoria do botão")
    .addOptions(botButtonCategories().slice(0, 25).map((c) => ({ label: c, value: c })));
}

export function buildAdmEmbedSelect(): StringSelectMenuBuilder {
  return new StringSelectMenuBuilder()
    .setCustomId("adm_embed_pick")
    .setPlaceholder("Escolha um embed para editar")
    .addOptions(
      EMBED_DEFS.slice(0, 25).map((e) => ({
        label: e.label.slice(0, 100),
        value: e.key,
        description: e.category.slice(0, 100),
      })),
    );
}

function isValidQueueValue(v: string): boolean {
  if (!v) return false;
  const cleaned = v.replace(",", ".");
  const num = Number(cleaned);
  if (Number.isNaN(num)) return false;
  if (num <= 0) return false;
  if (/^0+$/.test(v.replace(/[.,]/g, ""))) return false;
  return true;
}

function formatTaxa(num: number): string {
  if (num < 1) return num.toFixed(2);
  return num.toFixed(2).replace(".", ",");
}

async function refreshActiveQueueMessages(
  interaction: ButtonInteraction | ModalSubmitInteraction | AnySelectMenuInteraction,
): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId) return;
  const settings = await ensureGuildSettings(guildId);
  const enabledKeys = (settings.fila_botoes ?? "").split(",").filter(Boolean);
  for (const queue of activeQueues.values()) {
    if (queue.guildId !== guildId) continue;
    try {
      const channel = await interaction.client.channels.fetch(queue.channelId).catch(() => null);
      if (!channel || !("messages" in channel)) continue;
      const msg = await (channel as TextChannel).messages.fetch(queue.messageId).catch(() => null);
      if (!msg) continue;
      const embed = await buildQueueEmbed({
        guildId: queue.guildId,
        title: settings.fila_titulo ?? "FILA",
        modo: settings.fila_modo ?? queue.modo,
        tipo: settings.fila_tipo ?? queue.tipo,
        price: queue.price,
        banner: settings.fila_banner,
        thumb: settings.fila_thumb,
        enabledButtons: enabledKeys,
        players: [...queue.players.values()].map((p) => ({ userId: p.userId, buttonName: p.buttonName })),
      });
      const components = await buildQueueButtonsRows(queue.guildId, enabledKeys, queue.price);
      queue.modo = settings.fila_modo ?? queue.modo;
      queue.tipo = settings.fila_tipo ?? queue.tipo;
      await msg.edit({ embeds: [embed], components: components as never });
    } catch (err) {
      logger.warn({ err }, "Falha ao atualizar mensagem de fila ativa");
    }
  }
}

async function enviarFilas(interaction: ButtonInteraction): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const settings = await ensureGuildSettings(interaction.guildId!);
  const channel = interaction.channel as GuildTextBasedChannel | null;
  if (!channel || !("send" in channel)) {
    await interaction.editReply({ content: "Não consegui enviar neste canal." });
    return;
  }
  const valores = (settings.fila_valores ?? "0.50")
    .split(",")
    .map((v) => v.trim())
    .filter((v) => isValidQueueValue(v));
  if (valores.length === 0) {
    await interaction.editReply({ content: "❌ Nenhum valor válido. Defina valores (ex: 0.50, 1,00) — valores como '00' são ignorados." });
    return;
  }
  const enabledKeys = (settings.fila_botoes ?? "").split(",").filter(Boolean);

  for (const price of valores) {
    const embed = await buildQueueEmbed({
      guildId: interaction.guildId!,
      title: settings.fila_titulo ?? "FILA",
      modo: settings.fila_modo ?? "1v1",
      tipo: settings.fila_tipo ?? "mobile",
      price,
      banner: settings.fila_banner,
      thumb: settings.fila_thumb,
      enabledButtons: enabledKeys,
      players: [],
    });
    const components = await buildQueueButtonsRows(interaction.guildId!, enabledKeys, price);
    const sent = await channel.send({ embeds: [embed], components: components as never });
    activeQueues.set(sent.id, {
      guildId: interaction.guildId!,
      channelId: sent.channelId,
      messageId: sent.id,
      modo: settings.fila_modo ?? "1v1",
      tipo: settings.fila_tipo ?? "mobile",
      price,
      players: new Map(),
    });
  }
  await interaction.editReply({ content: `✅ ${valores.length} fila(s) enviada(s).` });
}

async function filaJoin(interaction: ButtonInteraction, key: string, price: string): Promise<void> {
  const queue = activeQueues.get(interaction.message.id);
  const def = findButtonDef(key);
  if (!queue || !def) {
    await interaction.reply({ content: "Esta fila expirou. Reenvie pelo painel /filas.", ephemeral: true });
    return;
  }
  if (queue.players.has(interaction.user.id)) {
    queue.players.delete(interaction.user.id);
    await refreshQueueMessage(interaction, queue);
    await interaction.followUp({ content: "Você saiu da fila.", ephemeral: true });
    return;
  }

  const mediators = await listMediatorsInQueue(queue.guildId);
  if (mediators.length === 0) {
    await interaction.reply({
      content: "⚠️ **Nenhum mediador disponível na fila no momento.** Avise um mediador para entrar via `/fila mediador` antes de iniciar a partida.",
      ephemeral: true,
    });
    return;
  }

  queue.players.set(interaction.user.id, { userId: interaction.user.id, buttonKey: key, buttonName: def.defaultName });

  const sameButton = [...queue.players.values()].filter((p) => p.buttonKey === key);
  if (sameButton.length >= 2) {
    const [p1, p2] = sameButton.slice(0, 2) as [typeof sameButton[0], typeof sameButton[0]];
    queue.players.delete(p1.userId);
    queue.players.delete(p2.userId);
    await refreshQueueMessage(interaction, queue);
    await openConfirmChannel(interaction, queue, p1.userId, p2.userId, key, price);
    return;
  }
  await refreshQueueMessage(interaction, queue);
  await interaction.followUp({ content: `✅ Você entrou na fila de **${def.defaultName}** (${formatPrice(price)}).`, ephemeral: true });
}

async function filaSair(interaction: ButtonInteraction): Promise<void> {
  const queue = activeQueues.get(interaction.message.id);
  if (!queue) {
    await interaction.reply({ content: "Esta fila expirou.", ephemeral: true });
    return;
  }
  if (!queue.players.has(interaction.user.id)) {
    await interaction.reply({ content: "Você não está nesta fila.", ephemeral: true });
    return;
  }
  queue.players.delete(interaction.user.id);
  await refreshQueueMessage(interaction, queue);
  await interaction.followUp({ content: "✅ Você saiu da fila.", ephemeral: true });
}

async function refreshQueueMessage(interaction: ButtonInteraction, queue: ReturnType<typeof activeQueues.get> & object): Promise<void> {
  const settings = await ensureGuildSettings(queue.guildId);
  const enabledKeys = (settings.fila_botoes ?? "").split(",").filter(Boolean);
  const embed = await buildQueueEmbed({
    guildId: queue.guildId,
    title: settings.fila_titulo ?? "FILA",
    modo: queue.modo,
    tipo: queue.tipo,
    price: queue.price,
    banner: settings.fila_banner,
    thumb: settings.fila_thumb,
    enabledButtons: enabledKeys,
    players: [...queue.players.values()].map((p) => ({ userId: p.userId, buttonName: p.buttonName })),
  });
  const components = await buildQueueButtonsRows(queue.guildId, enabledKeys, queue.price);
  await interaction.update({ embeds: [embed], components: components as never });
}

async function openConfirmChannel(
  interaction: ButtonInteraction,
  queue: NonNullable<ReturnType<typeof activeQueues.get>>,
  player1: string,
  player2: string,
  buttonKey: string,
  price: string,
): Promise<void> {
  const guild = interaction.guild!;
  const settings = await ensureGuildSettings(guild.id);
  const parent = settings.match_channel
    ? (await guild.channels.fetch(settings.match_channel).catch(() => null))?.parentId
    : null;

  const channel = await guild.channels.create({
    name: `confirmar-${player1.slice(-4)}-${player2.slice(-4)}`,
    type: ChannelType.GuildText,
    parent: parent ?? undefined,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: player1, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      { id: player2, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
      ...(settings.cargo_mediador ? [{ id: settings.cargo_mediador, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }] : []),
      ...(settings.cargo_admin ? [{ id: settings.cargo_admin, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }] : []),
    ],
  });

  const def = findButtonDef(buttonKey);
  const baseDesc = [
    `**Jogadores:** <@${player1}> vs <@${player2}>`,
    `**Tipo:** ${def?.defaultName ?? buttonKey}`,
    `**Modo:** ${queue.modo} ${queue.tipo}`,
    `**Valor:** ${formatPrice(price)}`,
    "",
    "Cada jogador deve clicar em **Confirmar** para iniciar. Se alguém clicar em **Cancelar**, este canal será fechado.",
    "",
    settings.aviso ?? "Boa partida a todos!",
  ].join("\n");
  const embed = await buildEmbedFromKey("match_found", { description: baseDesc });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("match_confirm", { label: "Confirmar", style: ButtonStyle.Success }),
    await buildBotButton("match_cancel", { label: "Cancelar", style: ButtonStyle.Danger }),
  );

  const sent = await channel.send({
    content: `<@${player1}> <@${player2}>`,
    embeds: [embed],
    components: [row],
  });

  activeMatches.set(channel.id, {
    guildId: guild.id,
    channelId: channel.id,
    panelMessageId: sent.id,
    player1,
    player2,
    buttonKey,
    price,
    modo: queue.modo,
    tipo: queue.tipo,
    confirmed: new Set(),
    mediatorId: null,
    mediatorPanelMessageId: null,
    analystId: null,
  });

  await interaction.followUp({ content: `🎯 Partida encontrada! Veja em <#${channel.id}>.`, ephemeral: true });
}

async function matchConfirm(interaction: ButtonInteraction): Promise<void> {
  const match = activeMatches.get(interaction.channelId!);
  if (!match) {
    await interaction.reply({ content: "Esta partida não existe mais.", ephemeral: true });
    return;
  }
  if (interaction.user.id !== match.player1 && interaction.user.id !== match.player2) {
    await interaction.reply({ content: "Apenas os jogadores podem confirmar.", ephemeral: true });
    return;
  }
  match.confirmed.add(interaction.user.id);
  await interaction.reply({ content: `✅ Você confirmou. Aguardando o outro jogador.`, ephemeral: true });
  if (match.confirmed.size >= 2) {
    await summonMediator(interaction, match);
  }
}

async function matchCancel(interaction: ButtonInteraction): Promise<void> {
  const match = activeMatches.get(interaction.channelId!);
  if (!match) {
    await interaction.reply({ content: "Esta partida não existe mais.", ephemeral: true });
    return;
  }
  await interaction.reply({ content: "❌ Partida cancelada. Fechando canal..." });
  activeMatches.delete(match.channelId);
  setTimeout(async () => {
    try {
      await interaction.guild?.channels.delete(match.channelId, "Partida cancelada");
    } catch (err) {
      logger.warn({ err }, "Falha ao deletar canal de partida");
    }
  }, 3000);
}

async function summonMediator(
  interaction: ButtonInteraction,
  match: NonNullable<ReturnType<typeof activeMatches.get>>,
): Promise<void> {
  const mediatorId = await popNextMediator(match.guildId);
  if (!mediatorId) {
    const channel = interaction.channel as GuildTextBasedChannel;
    await channel.send({ content: "⚠️ Nenhum mediador disponível na fila. Avisem um mediador para entrar via `/fila mediador`." });
    return;
  }
  match.mediatorId = mediatorId;
  const channel = interaction.channel as TextChannel;
  await channel.permissionOverwrites.edit(mediatorId, { ViewChannel: true, SendMessages: true });

  const embed = await buildEmbedFromKey("mediador_chamado", {
    description: `<@${mediatorId}>, você foi chamado para mediar esta partida entre <@${match.player1}> e <@${match.player2}>.`,
  });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("med_lib_qr", { label: "Liberar QR Code", style: ButtonStyle.Primary }),
    await buildBotButton("med_lib_chave", { label: "Liberar chave PIX", style: ButtonStyle.Success }),
    await buildBotButton("med_def_vencedor", { label: "Definir vencedor", style: ButtonStyle.Danger }),
    await buildBotButton("med_chamar_analista", { label: "Chamar analista", style: ButtonStyle.Primary }),
  );
  const sent = await channel.send({ content: `<@${mediatorId}>`, embeds: [embed], components: [row] });
  match.mediatorPanelMessageId = sent.id;
}

async function chamarAnalista(interaction: ButtonInteraction): Promise<void> {
  const match = activeMatches.get(interaction.channelId!);
  if (!match) {
    await interaction.reply({ content: "Esta partida não existe mais.", ephemeral: true });
    return;
  }
  if (match.mediatorId !== interaction.user.id) {
    await interaction.reply({ content: "Apenas o mediador desta partida pode chamar um analista.", ephemeral: true });
    return;
  }
  if (match.analystId) {
    await interaction.reply({ content: `Um analista já foi chamado: <@${match.analystId}>.`, ephemeral: true });
    return;
  }
  const analystId = await popNextAnalyst(match.guildId);
  if (!analystId) {
    await interaction.reply({ content: "⚠️ Nenhum analista disponível na fila. Use `/fila analista` para entrar.", ephemeral: true });
    return;
  }
  match.analystId = analystId;
  const channel = interaction.channel as TextChannel;
  await channel.permissionOverwrites.edit(analystId, { ViewChannel: true, SendMessages: true });

  const embed = await buildEmbedFromKey("analista_chamado", {
    description: `<@${analystId}>, você foi chamado para analisar esta partida entre <@${match.player1}> e <@${match.player2}>.`,
  });
  await channel.send({ content: `<@${analystId}>`, embeds: [embed] });
  await interaction.reply({ content: `✅ Analista <@${analystId}> chamado.`, ephemeral: true });
}

async function liberarQrCode(interaction: ButtonInteraction): Promise<void> {
  const match = activeMatches.get(interaction.channelId!);
  if (!match || match.mediatorId !== interaction.user.id) {
    await interaction.reply({ content: "Apenas o mediador desta partida pode usar.", ephemeral: true });
    return;
  }
  const pix = await getMediatorPix(match.guildId, interaction.user.id);
  if (!pix) {
    await interaction.reply({ content: "❌ Configure seu PIX primeiro em `/fila mediador`.", ephemeral: true });
    return;
  }
  const settings = await ensureGuildSettings(match.guildId);
  await interaction.deferReply();
  try {
    const png = await generatePixQrPng(
      { ...pix, amount: match.price.replace(",", ".") },
      settings.qr_color ?? "#000000",
      settings.qr_border_color ?? "#FFFFFF",
    );
    const file = new AttachmentBuilder(png, { name: "pix.png" });
    const embed = await buildEmbedFromKey("qr_code", {
      description: `Pague **${formatPrice(match.price)}** lendo o QR Code abaixo.\nTitular: **${pix.titular}** • ${pix.cidade}`,
    });
    embed.setImage("attachment://pix.png");
    await interaction.editReply({ embeds: [embed], files: [file] });
  } catch (err) {
    logger.error({ err }, "Erro ao gerar QR Code");
    await interaction.editReply({ content: "❌ Erro ao gerar QR Code." });
  }
}

async function liberarChave(interaction: ButtonInteraction): Promise<void> {
  const match = activeMatches.get(interaction.channelId!);
  if (!match || match.mediatorId !== interaction.user.id) {
    await interaction.reply({ content: "Apenas o mediador desta partida pode usar.", ephemeral: true });
    return;
  }
  const pix = await getMediatorPix(match.guildId, interaction.user.id);
  if (!pix) {
    await interaction.reply({ content: "❌ Configure seu PIX primeiro.", ephemeral: true });
    return;
  }
  const embed = await buildEmbedFromKey("chave_pix", {
    description: `\`\`\`${pix.chave}\`\`\`\nTitular: **${pix.titular}**\nCidade: **${pix.cidade}**`,
  });
  await interaction.reply({ embeds: [embed] });
}

async function abrirSelectVencedor(interaction: ButtonInteraction): Promise<void> {
  const match = activeMatches.get(interaction.channelId!);
  if (!match || match.mediatorId !== interaction.user.id) {
    await interaction.reply({ content: "Apenas o mediador desta partida pode usar.", ephemeral: true });
    return;
  }
  const p1 = await interaction.client.users.fetch(match.player1).catch(() => null);
  const p2 = await interaction.client.users.fetch(match.player2).catch(() => null);
  const select = new StringSelectMenuBuilder()
    .setCustomId(`def_vencedor_select:${interaction.channelId}`)
    .setPlaceholder("Quem venceu?")
    .addOptions(
      { label: p1?.username ?? match.player1, value: match.player1 },
      { label: p2?.username ?? match.player2, value: match.player2 },
    );
  await interaction.reply({
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
    ephemeral: true,
  });
}

async function definirVencedor(
  interaction: StringSelectMenuInteraction,
  channelId: string,
  winnerId: string,
): Promise<void> {
  const match = activeMatches.get(channelId);
  if (!match) {
    await interaction.update({ content: "Partida não encontrada.", components: [] });
    return;
  }
  const settings = await ensureGuildSettings(match.guildId);
  const loserId = winnerId === match.player1 ? match.player2 : match.player1;
  await recordMatch(match.guildId, match.player1, match.player2, winnerId, match.mediatorId, Number(match.price.replace(",", ".")));
  await addCoins(match.guildId, winnerId, settings.coin_winner ?? 10);
  await addCoins(match.guildId, loserId, settings.coin_loser ?? 2);

  const channel = interaction.channel as GuildTextBasedChannel;
  const embed = await buildEmbedFromKey("vencedor", {
    description: `Vencedor: <@${winnerId}>\nDerrotado: <@${loserId}>\n\nO canal será fechado em 10s.`,
  });
  await channel.send({ embeds: [embed] });
  await interaction.update({ content: `✅ Vencedor registrado.`, components: [] });
  activeMatches.delete(channelId);
  setTimeout(async () => {
    try {
      await (channel as TextChannel).delete("Partida finalizada");
    } catch (err) {
      logger.warn({ err }, "Falha ao deletar canal pós-partida");
    }
  }, 10000);
}

async function openMediatorPixModal(interaction: ButtonInteraction): Promise<void> {
  const ok = await isMediator(interaction.member as never);
  if (!ok) {
    await interaction.reply({ content: "❌ Apenas mediadores podem configurar PIX.", ephemeral: true });
    return;
  }
  const existing = await getMediatorPix(interaction.guildId!, interaction.user.id);
  const modal = new ModalBuilder().setCustomId("med_pix_modal").setTitle("Configurar PIX do mediador");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId("chave").setLabel("Chave PIX").setStyle(TextInputStyle.Short).setValue(existing?.chave ?? "").setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId("titular").setLabel("Nome do titular").setStyle(TextInputStyle.Short).setValue(existing?.titular ?? "").setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder().setCustomId("cidade").setLabel("Cidade").setStyle(TextInputStyle.Short).setValue(existing?.cidade ?? "").setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function mediatorEntrar(interaction: ButtonInteraction): Promise<void> {
  const ok = await isMediator(interaction.member as never);
  if (!ok) {
    await interaction.reply({ content: "❌ Você não é um mediador.", ephemeral: true });
    return;
  }
  const pix = await getMediatorPix(interaction.guildId!, interaction.user.id);
  if (!pix) {
    await interaction.reply({ content: "❌ Configure seu PIX primeiro.", ephemeral: true });
    return;
  }
  await addMediatorToQueue(interaction.guildId!, interaction.user.id, interaction.message.id);
  await refreshMediatorPanel(interaction);
  await interaction.followUp({ content: "✅ Você entrou na fila de mediadores.", ephemeral: true });
}

async function mediatorSair(interaction: ButtonInteraction): Promise<void> {
  await removeMediatorFromQueue(interaction.guildId!, interaction.user.id);
  await refreshMediatorPanel(interaction);
  await interaction.followUp({ content: "Você saiu da fila de mediadores.", ephemeral: true });
}

async function refreshMediatorPanel(interaction: ButtonInteraction): Promise<void> {
  const guildId = interaction.guildId!;
  const mediators = await (await import("../lib/store")).listMediatorsInQueue(guildId);
  const lines = ["**Mediadores na fila:**"];
  if (mediators.length === 0) lines.push("_Nenhum mediador na fila no momento._");
  else mediators.forEach((id, i) => lines.push(`${i + 1}. <@${id}>`));

  const embed = await buildEmbedFromKey("fila_mediador", {
    description: ["Mediadores podem configurar seu PIX e entrar na fila para serem chamados em partidas.", "", ...lines].join("\n"),
  });
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("med_pix", { label: "Configurar PIX", style: ButtonStyle.Primary }),
    await buildBotButton("med_entrar", { label: "Entrar na fila", style: ButtonStyle.Success }),
    await buildBotButton("med_sair", { label: "Sair", style: ButtonStyle.Danger }),
  );
  await interaction.update({ embeds: [embed], components: [row] });
}

async function analystEntrar(interaction: ButtonInteraction): Promise<void> {
  const settings = await ensureGuildSettings(interaction.guildId!);
  if (settings.cargo_analista) {
    const member = interaction.member as { roles?: { cache?: { has?: (id: string) => boolean } } } | null;
    const has = member?.roles?.cache?.has?.(settings.cargo_analista);
    if (!has) {
      await interaction.reply({ content: "❌ Você não tem o cargo de analista.", ephemeral: true });
      return;
    }
  }
  await addAnalystToQueue(interaction.guildId!, interaction.user.id, interaction.message.id);
  await refreshAnalystPanel(interaction);
  await interaction.followUp({ content: "✅ Você entrou na fila de analistas.", ephemeral: true });
}

async function analystSair(interaction: ButtonInteraction): Promise<void> {
  await removeAnalystFromQueue(interaction.guildId!, interaction.user.id);
  await refreshAnalystPanel(interaction);
  await interaction.followUp({ content: "Você saiu da fila de analistas.", ephemeral: true });
}

async function refreshAnalystPanel(interaction: ButtonInteraction): Promise<void> {
  const guildId = interaction.guildId!;
  const analysts = await listAnalystsInQueue(guildId);
  const lines = ["**Analistas na fila:**"];
  if (analysts.length === 0) lines.push("_Nenhum analista na fila no momento._");
  else analysts.forEach((id, i) => lines.push(`${i + 1}. <@${id}>`));

  const embed = await buildEmbedFromKey("fila_analista", {
    description: ["Analistas entram na fila e podem ser chamados pelos mediadores no canal de partida.", "", ...lines].join("\n"),
  });
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    await buildBotButton("anal_entrar", { label: "Entrar na fila", style: ButtonStyle.Success }),
    await buildBotButton("anal_sair", { label: "Sair", style: ButtonStyle.Danger }),
  );
  await interaction.update({ embeds: [embed], components: [row] });
}

const TIPO_LABELS: Record<string, string> = {
  cargo: "Cargo",
  dinheiro: "Dinheiro",
  giros: "Giros",
  personalizado: "Personalizado",
};

function normalizarTipo(raw: string): string {
  const v = raw.trim().toLowerCase();
  if (["cargo", "role"].includes(v)) return "cargo";
  if (["dinheiro", "money", "coins", "coin"].includes(v)) return "dinheiro";
  if (["giros", "giro", "spin", "spins"].includes(v)) return "giros";
  if (["personalizado", "custom", "outro"].includes(v)) return "personalizado";
  return v || "personalizado";
}

function formatPremio(item: { id: number; name: string; price: string | number; item_type: string; item_value: string | null; description: string | null }): string {
  const tipo = TIPO_LABELS[item.item_type] ?? item.item_type;
  const valor = item.item_value ? ` — \`${item.item_value}\`` : "";
  const desc = item.description ? `\n  _${item.description}_` : "";
  return `**#${item.id}** • ${item.name} — **${item.price}** coins • ${tipo}${valor}${desc}`;
}

async function previewFilas(interaction: ButtonInteraction): Promise<void> {
  const settings = await ensureGuildSettings(interaction.guildId!);
  const enabledKeys = (settings.fila_botoes ?? "").split(",").filter(Boolean);
  const valores = (settings.fila_valores ?? "0.50")
    .split(",")
    .map((v) => v.trim())
    .filter((v) => v.length > 0);
  const price = valores[0] ?? "0.50";

  const embed = await buildQueueEmbed({
    guildId: interaction.guildId!,
    title: settings.fila_titulo ?? "FILA",
    modo: settings.fila_modo ?? "1v1",
    tipo: settings.fila_tipo ?? "mobile",
    price,
    banner: settings.fila_banner,
    thumb: settings.fila_thumb,
    enabledButtons: enabledKeys,
    players: [],
  });
  const components = await buildQueueButtonsRows(interaction.guildId!, enabledKeys, price);

  const previewComponents = components.map((row) => {
    const newRow = new ActionRowBuilder<ButtonBuilder>();
    for (const c of row.components) {
      const data = (c as ButtonBuilder).data as { label?: string; style?: ButtonStyle; emoji?: unknown };
      const btn = new ButtonBuilder()
        .setCustomId(`preview_disabled:${Math.random().toString(36).slice(2, 8)}`)
        .setLabel(data.label ?? " ")
        .setStyle(data.style ?? ButtonStyle.Secondary)
        .setDisabled(true);
      if (data.emoji) btn.setEmoji(data.emoji as never);
      newRow.addComponents(btn);
    }
    return newRow;
  });

  await interaction.reply({
    content: `**Pré-visualização da fila** (${valores.length} valor(es) configurado(s); mostrando o primeiro: \`${price}\`)`,
    embeds: [embed],
    components: previewComponents as never,
    ephemeral: true,
  });
}

async function openLojaAddModal(interaction: ButtonInteraction): Promise<void> {
  const modal = new ModalBuilder().setCustomId("loja_add_modal").setTitle("Adicionar prêmio");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("tipo")
        .setLabel("Tipo: cargo, dinheiro, giros ou personalizado")
        .setStyle(TextInputStyle.Short)
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("nome")
        .setLabel("Nome do prêmio")
        .setStyle(TextInputStyle.Short)
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("preco")
        .setLabel("Preço em coins")
        .setStyle(TextInputStyle.Short)
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("valor")
        .setLabel("Valor (ID do cargo, qtd, R$, ou texto)")
        .setStyle(TextInputStyle.Short)
        .setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function openLojaItemModal(interaction: StringSelectMenuInteraction, itemId: number): Promise<void> {
  const item = await getShopItem(itemId);
  if (!item) {
    await interaction.update({ content: "❌ Prêmio não encontrado.", components: [] });
    return;
  }
  const modal = new ModalBuilder().setCustomId(`loja_edit_modal:${itemId}`).setTitle(`Editar prêmio #${itemId}`);
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("tipo")
        .setLabel("Tipo: cargo, dinheiro, giros ou personalizado")
        .setStyle(TextInputStyle.Short)
        .setValue(item.item_type)
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("nome")
        .setLabel("Nome do prêmio")
        .setStyle(TextInputStyle.Short)
        .setValue(item.name)
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("preco")
        .setLabel("Preço em coins")
        .setStyle(TextInputStyle.Short)
        .setValue(String(item.price))
        .setRequired(true),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("valor")
        .setLabel("Valor (ID do cargo, qtd, R$, ou texto)")
        .setStyle(TextInputStyle.Short)
        .setValue(item.item_value ?? "")
        .setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function submitLojaItemModal(interaction: ModalSubmitInteraction): Promise<void> {
  const guildId = interaction.guildId!;
  const isEdit = interaction.customId.startsWith("loja_edit_modal:");
  const editId = isEdit ? Number(interaction.customId.split(":")[1]) : null;

  const tipo = normalizarTipo(interaction.fields.getTextInputValue("tipo"));
  const nome = interaction.fields.getTextInputValue("nome").trim();
  const precoRaw = interaction.fields.getTextInputValue("preco").trim().replace(",", ".");
  const valor = interaction.fields.getTextInputValue("valor").trim() || null;
  const preco = Number(precoRaw);

  if (!nome || Number.isNaN(preco) || preco < 0) {
    await interaction.reply({ content: "❌ Nome e preço (número >= 0) são obrigatórios.", ephemeral: true });
    return;
  }
  if (!["cargo", "dinheiro", "giros", "personalizado"].includes(tipo)) {
    await interaction.reply({
      content: "❌ Tipo inválido. Use: `cargo`, `dinheiro`, `giros` ou `personalizado`.",
      ephemeral: true,
    });
    return;
  }

  if (isEdit && editId !== null) {
    await updateShopItem(editId, { name: nome, price: preco, item_type: tipo, item_value: valor });
    await interaction.reply({ content: `✅ Prêmio **#${editId}** atualizado.`, ephemeral: true });
  } else {
    const newId = await addShopItem(guildId, { name: nome, price: preco, item_type: tipo, item_value: valor });
    await interaction.reply({ content: `✅ Prêmio **#${newId} — ${nome}** adicionado.`, ephemeral: true });
  }
}

async function openLojaRemoverSelect(interaction: ButtonInteraction): Promise<void> {
  const items = await listShopItems(interaction.guildId!);
  if (items.length === 0) {
    await interaction.reply({ content: "❌ Nenhum prêmio cadastrado.", ephemeral: true });
    return;
  }
  const select = new StringSelectMenuBuilder()
    .setCustomId("loja_rem_select")
    .setPlaceholder("Escolha o prêmio para remover")
    .addOptions(
      items.slice(0, 25).map((it) => ({
        label: `#${it.id} • ${it.name}`.slice(0, 100),
        description: `${it.price} coins — ${TIPO_LABELS[it.item_type] ?? it.item_type}`.slice(0, 100),
        value: String(it.id),
      })),
    );
  await interaction.reply({
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
    ephemeral: true,
  });
}

async function openLojaEditarSelect(interaction: ButtonInteraction): Promise<void> {
  const items = await listShopItems(interaction.guildId!);
  if (items.length === 0) {
    await interaction.reply({ content: "❌ Nenhum prêmio cadastrado.", ephemeral: true });
    return;
  }
  const select = new StringSelectMenuBuilder()
    .setCustomId("loja_edit_select")
    .setPlaceholder("Escolha o prêmio para editar")
    .addOptions(
      items.slice(0, 25).map((it) => ({
        label: `#${it.id} • ${it.name}`.slice(0, 100),
        description: `${it.price} coins — ${TIPO_LABELS[it.item_type] ?? it.item_type}`.slice(0, 100),
        value: String(it.id),
      })),
    );
  await interaction.reply({
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
    ephemeral: true,
  });
}

async function mostrarLojaPremios(interaction: ButtonInteraction): Promise<void> {
  const items = await listShopItems(interaction.guildId!);
  const appearance = await getShopAppearance(interaction.guildId!);

  const lines = items.length
    ? items.map((it) => formatPremio(it))
    : ["_Nenhum prêmio cadastrado ainda. Use **Adicionar** para começar._"];

  const embed = await buildEmbedFromKey("loja_coins", {
    description: ["**Prêmios da loja:**", "", ...lines].join("\n"),
  });
  if (appearance.banner) embed.setImage(appearance.banner);
  if (appearance.thumb) embed.setThumbnail(appearance.thumb);
  await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function openLojaImagensModal(interaction: ButtonInteraction): Promise<void> {
  const appearance = await getShopAppearance(interaction.guildId!);
  const modal = new ModalBuilder().setCustomId("loja_img_modal").setTitle("Imagens da loja");
  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("banner")
        .setLabel("URL do banner (suporta gif animado)")
        .setStyle(TextInputStyle.Short)
        .setValue(appearance.banner ?? "")
        .setRequired(false),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("thumb")
        .setLabel("URL da thumbnail (suporta gif animado)")
        .setStyle(TextInputStyle.Short)
        .setValue(appearance.thumb ?? "")
        .setRequired(false),
    ),
  );
  await interaction.showModal(modal);
}

async function submitLojaImagensModal(interaction: ModalSubmitInteraction): Promise<void> {
  const banner = interaction.fields.getTextInputValue("banner").trim() || null;
  const thumb = interaction.fields.getTextInputValue("thumb").trim() || null;
  await setShopAppearance(interaction.guildId!, { banner, thumb });
  await interaction.reply({
    content: `✅ Imagens salvas.\n• Banner: ${banner ? "atualizado" : "removido"}\n• Thumbnail: ${thumb ? "atualizado" : "removida"}`,
    ephemeral: true,
  });
}

async function openLojaEnviarSelect(interaction: ButtonInteraction): Promise<void> {
  const items = await listShopItems(interaction.guildId!);
  if (items.length === 0) {
    await interaction.reply({ content: "❌ Nenhum prêmio cadastrado.", ephemeral: true });
    return;
  }
  const select = new StringSelectMenuBuilder()
    .setCustomId("loja_send_item_select")
    .setPlaceholder("Escolha o prêmio para enviar")
    .addOptions(
      items.slice(0, 25).map((it) => ({
        label: `#${it.id} • ${it.name}`.slice(0, 100),
        description: `${it.price} coins — ${TIPO_LABELS[it.item_type] ?? it.item_type}`.slice(0, 100),
        value: String(it.id),
      })),
    );
  await interaction.reply({
    content: "Escolha o prêmio que será enviado:",
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
    ephemeral: true,
  });
}

async function enviarPremio(
  interaction: UserSelectMenuInteraction,
  itemId: number,
  userId: string,
): Promise<void> {
  const item = await getShopItem(itemId);
  if (!item) {
    await interaction.update({ content: "❌ Prêmio não encontrado.", components: [] });
    return;
  }
  const guild = interaction.guild;
  if (!guild) {
    await interaction.update({ content: "❌ Servidor inválido.", components: [] });
    return;
  }

  const tipo = item.item_type;
  let entregaInfo = "";
  let erroEntrega: string | null = null;

  try {
    if (tipo === "cargo" && item.item_value) {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member) erroEntrega = "Usuário não encontrado no servidor.";
      else {
        await member.roles.add(item.item_value);
        entregaInfo = `Cargo <@&${item.item_value}> adicionado.`;
      }
    } else if (tipo === "dinheiro") {
      entregaInfo = `Valor a pagar: **R$ ${item.item_value ?? "?"}** (entrega manual via PIX).`;
    } else if (tipo === "giros") {
      entregaInfo = `Giros concedidos: **${item.item_value ?? "?"}** (uso manual em sorteios).`;
    } else {
      entregaInfo = item.item_value ? `Detalhes: ${item.item_value}` : "Prêmio personalizado entregue.";
    }
  } catch (err) {
    erroEntrega = (err as Error).message;
  }

  const desc = [
    `Prêmio: **${item.name}**`,
    `Tipo: **${TIPO_LABELS[tipo] ?? tipo}**`,
    `Valor pago: **${item.price}** coins`,
    "",
    entregaInfo,
  ].join("\n");

  const embed = await buildEmbedFromKey("loja_premio_recebido", { description: desc });
  const channel = interaction.channel as GuildTextBasedChannel | null;
  if (channel && "send" in channel) {
    await channel.send({ content: `<@${userId}>`, embeds: [embed] });
  }

  await interaction.update({
    content: erroEntrega
      ? `⚠️ Prêmio enviado, mas houve erro na entrega automática: ${erroEntrega}`
      : `✅ Prêmio **${item.name}** enviado para <@${userId}>.`,
    components: [],
  });
}
