import {
  type Interaction,
  type ChatInputCommandInteraction,
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type AnySelectMenuInteraction,
  EmbedBuilder,
} from "discord.js";
import { handleSlashCommand } from "./slashCommands";
import { handleComponent } from "./componentRouter";

export async function handleInteraction(interaction: Interaction): Promise<void> {
  if (interaction.isChatInputCommand()) {
    await handleSlashCommand(interaction as ChatInputCommandInteraction);
    return;
  }
  if (interaction.isButton()) {
    await handleComponent.button(interaction as ButtonInteraction);
    return;
  }
  if (interaction.isModalSubmit()) {
    await handleComponent.modal(interaction as ModalSubmitInteraction);
    return;
  }
  if (interaction.isAnySelectMenu()) {
    await handleComponent.select(interaction as AnySelectMenuInteraction);
    return;
  }
}

export const _embedBuilderPlaceholder = EmbedBuilder;
