import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import type { ActiveQueue } from "../state";
import { QUEUE_BUTTON_DEFS } from "../data/buttonsCatalog";
import { getQueueButtons, getEmbedOverride, getGlobalButton } from "../lib/store";
import { parseButtonColor } from "../lib/colors";
import { parseEmojiInput } from "../lib/emoji";
import { buildBotButton } from "./buttonHelper";

export interface QueueEmbedInput {
  guildId: string;
  title: string;
  modo: string;
  tipo: string;
  price: string;
  banner: string | null;
  thumb: string | null;
  enabledButtons: string[];
  players: { userId: string; buttonName: string }[];
}

const SQUARE_PIXEL =
  "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Solid_white.svg/2048px-Solid_white.svg.png";

export function formatPrice(price: string): string {
  const v = price.trim();
  if (!v) return "0.50";
  return v;
}

function parseHexColor(hex: string | null | undefined): number | null {
  if (!hex) return null;
  const clean = hex.replace("#", "").trim();
  if (!/^[0-9A-Fa-f]{6}$/.test(clean)) return null;
  return parseInt(clean, 16);
}

export async function buildQueueEmbed(input: QueueEmbedInput): Promise<EmbedBuilder> {
  const override = await getEmbedOverride("queue_main");

  const lines: string[] = [];
  lines.push("**Modo**");
  lines.push(`${input.modo} ${input.tipo}`);
  lines.push("");
  lines.push("**preço**");
  lines.push(formatPrice(input.price));
  if (input.players.length > 0) {
    lines.push("");
    lines.push("**Jogadores**");
    for (const p of input.players) {
      lines.push(`<@${p.userId}> • ${p.buttonName}`);
    }
  }

  const title = override?.title ?? input.title ?? "FILA";
  const description = override?.description
    ? `${override.description}\n\n${lines.join("\n")}`
    : lines.join("\n");
  const colorNum = parseHexColor(override?.color) ?? 0x2b2d31;

  const embed = new EmbedBuilder()
    .setTitle(title || "FILA")
    .setDescription(description)
    .setColor(colorNum);

  const banner = input.banner ?? override?.image_url ?? null;
  const thumb = input.thumb ?? override?.thumb_url ?? null;
  if (banner) embed.setImage(banner);
  if (thumb) embed.setThumbnail(thumb);
  if (override?.footer) embed.setFooter({ text: override.footer });
  return embed;
}

export async function buildQueueButtonsRows(
  guildId: string,
  enabledKeys: string[],
  price: string,
): Promise<ActionRowBuilder<ButtonBuilder>[]> {
  const overrides = await getQueueButtons(guildId);
  const overrideMap = new Map(overrides.map((o) => [o.button_key, o]));

  const buttons = enabledKeys
    .map((key) => QUEUE_BUTTON_DEFS.find((b) => b.key === key))
    .filter((b): b is (typeof QUEUE_BUTTON_DEFS)[number] => Boolean(b));

  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  let current = new ActionRowBuilder<ButtonBuilder>();

  for (const def of buttons) {
    const ov = overrideMap.get(def.key);
    const globalOv = await getGlobalButton(def.key);
    const name = ov?.name ?? globalOv?.name ?? def.defaultName;
    const color = parseButtonColor(ov?.color ?? globalOv?.color ?? def.defaultColor);
    const button = new ButtonBuilder()
      .setCustomId(`fila_join:${def.key}:${price}`)
      .setStyle(color)
      .setLabel(name);
    const emoji = parseEmojiInput(ov?.emoji ?? globalOv?.emoji ?? null);
    if (emoji) button.setEmoji(emoji);
    if (current.components.length === 5) {
      rows.push(current);
      current = new ActionRowBuilder<ButtonBuilder>();
    }
    current.addComponents(button);
  }

  const sairBtn = await buildBotButton("fila_sair", { label: "Sair da fila", style: ButtonStyle.Secondary, customId: "fila_sair" });
  if (current.components.length === 5) {
    rows.push(current);
    current = new ActionRowBuilder<ButtonBuilder>();
  }
  current.addComponents(sairBtn);

  if (current.components.length > 0) rows.push(current);
  return rows;
}

export { SQUARE_PIXEL };
