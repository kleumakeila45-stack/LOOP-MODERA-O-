import { EmbedBuilder } from "discord.js";
import { findEmbedDef } from "../data/embedsCatalog";
import { getEmbedOverride } from "../lib/store";

function parseHexColor(hex: string | null | undefined): number | null {
  if (!hex) return null;
  const clean = hex.replace("#", "").trim();
  if (!/^[0-9A-Fa-f]{6}$/.test(clean)) return null;
  return parseInt(clean, 16);
}

export interface EmbedExtras {
  title?: string;
  description?: string;
  footer?: string;
  image?: string | null;
  thumbnail?: string | null;
  fields?: { name: string; value: string; inline?: boolean }[];
}

export async function buildEmbedFromKey(
  key: string,
  extras: EmbedExtras = {},
): Promise<EmbedBuilder> {
  const def = findEmbedDef(key);
  const override = await getEmbedOverride(key);

  const title = override?.title ?? extras.title ?? def?.defaultTitle ?? "";
  const description = (() => {
    if (extras.description) return extras.description;
    if (override?.description) return override.description;
    return def?.defaultDescription ?? "";
  })();
  const colorNum =
    parseHexColor(override?.color) ??
    parseHexColor(def?.defaultColor) ??
    0x5865f2;
  const footer = override?.footer ?? extras.footer ?? def?.defaultFooter ?? null;
  const image = extras.image !== undefined ? extras.image : override?.image_url ?? null;
  const thumb = extras.thumbnail !== undefined ? extras.thumbnail : override?.thumb_url ?? null;

  const embed = new EmbedBuilder().setColor(colorNum);
  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (footer) embed.setFooter({ text: footer });
  if (image) embed.setImage(image);
  if (thumb) embed.setThumbnail(thumb);
  if (extras.fields && extras.fields.length > 0) embed.addFields(extras.fields);
  return embed;
}
