import { ButtonBuilder, ButtonStyle } from "discord.js";
import { findBotButtonDef } from "../data/buttonsCatalog";
import { getGlobalButton } from "../lib/store";
import { parseEmojiInput } from "../lib/emoji";

function styleFromName(name: string | null | undefined, fallback: ButtonStyle): ButtonStyle {
  switch ((name ?? "").toLowerCase()) {
    case "primary":
      return ButtonStyle.Primary;
    case "success":
      return ButtonStyle.Success;
    case "danger":
      return ButtonStyle.Danger;
    case "secondary":
      return ButtonStyle.Secondary;
    default:
      return fallback;
  }
}

export async function buildBotButton(
  key: string,
  fallback: { label: string; style: ButtonStyle; customId?: string },
): Promise<ButtonBuilder> {
  const def = findBotButtonDef(key);
  const ov = await getGlobalButton(key);

  const label = ov?.name ?? def?.defaultName ?? fallback.label;
  const style = ov?.color
    ? styleFromName(ov.color, fallback.style)
    : def?.defaultColor
      ? styleFromName(def.defaultColor, fallback.style)
      : fallback.style;

  const btn = new ButtonBuilder()
    .setCustomId(fallback.customId ?? key)
    .setLabel(label)
    .setStyle(style);

  const emoji = parseEmojiInput(ov?.emoji ?? null);
  if (emoji) btn.setEmoji(emoji);

  return btn;
}
